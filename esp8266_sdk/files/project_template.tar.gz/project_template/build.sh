#!/bin/bash


[ "$XTENSA_TOOLS_ROOT" = "" ] && XTENSA_TOOLS_ROOT=$PWD/../esptools/xtensa-lx106-elf/bin/
[ "$SDK_PATH" = "" ] && SDK_PATH=$PWD/../esptools/esp-rtos-sdk-1.4

export PATH=$PATH:$XTENSA_TOOLS_ROOT 
export XTENSA_TOOLS_ROOT=$XTENSA_TOOLS_ROOT
export SDK_PATH=$SDK_PATH
export BIN_PATH=./bin


echo ""
echo "building... "
echo ""

# sh gen_misc.sh 
boot=new
app=0
spi_speed=40 
spi_mode=DIO 
spi_size_map=6

make clean	
make $1 BOOT=$boot APP=$app SPI_SPEED=$spi_speed SPI_MODE=$spi_mode SPI_SIZE_MAP=$spi_size_map 
