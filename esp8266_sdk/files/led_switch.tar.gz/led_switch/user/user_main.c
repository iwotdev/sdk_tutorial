/******************************************************************************
 * Copyright (C)   Espressif System with iWoT 
 *
 * FileName: user_main.c
 *
 * Description: Connect and receive actions from iWoT cloud to switch led on/off.
 *
 * Modification history:
 * 2017/01/11, v1.9 create this file.
*******************************************************************************/

#include <stdio.h>
#include "esp_common.h"
#include "uart.h"

#include "iwot.h"
#include "gpio.h"
THING *thing = 0;
IWOTCONFIG *iwotConfig = 0;

uint32 user_rf_cal_sector_set(void)
{
    flash_size_map size_map = system_get_flash_size_map();
    uint32 rf_cal_sec = 0;

    switch (size_map) {
        case FLASH_SIZE_4M_MAP_256_256:
            rf_cal_sec = 128 - 5;
            break;

        case FLASH_SIZE_8M_MAP_512_512:
            rf_cal_sec = 256 - 5;
            break;

        case FLASH_SIZE_16M_MAP_512_512:
        case FLASH_SIZE_16M_MAP_1024_1024:
            rf_cal_sec = 512 - 5;
            break;

        case FLASH_SIZE_32M_MAP_512_512:
        case FLASH_SIZE_32M_MAP_1024_1024:
            rf_cal_sec = 1024 - 5;
            break;

        default:
            rf_cal_sec = 0;
            break;
    }

    return rf_cal_sec;
}

/******************************************************************************
 * FunctionName : actionHandler
 * Description  :  actions handler of iWoT here
 * Parameters   : IWOTVAROBJECT *
 * Returns      : 0 for succeed, 1 for failed 
*******************************************************************************/
int actionHandler(IWOTVAROBJECT *var)
{
  printf("[actionHandler]%s \n","ENTER!");
  IWOTVARGROUP **groups = var->groups;
  IWOTVARITEM **items;

  int s = 0;
  int i, j;
  
  for (i = 0; i < var->groupCount; i++, groups++) {  
    
    if(0 == strcmp((*groups)->identifier, "switch")) {
      items = (*groups)->items;  
      for (j = 0; j < (*groups)->itemCount; j++, items++) {
        if (0 == strcmp((*items)->key, "ledState")) {
          s = (*items)->value.integer;  
          printf("switch ledState to :%d \n",s);
          GPIO_OUTPUT(GPIO_Pin_5, s);
        } 
      }    
    }          
  }

  return 0;
}

/******************************************************************************
 * FunctionName : connect_iWoT
 * Description  :  Connect to iWoT here
 * Parameters   : none
 * Returns      : 1 for successfully connected
*******************************************************************************/
int connect_iWoT() 
{
  char *host = "192.168.22.3"; // "dev.iwot.io"; // 
  char *accessKey = "Ms5jyA-Ii31UitzZuJxKmnvf"; // "your_access_key"; //
  char *secretKey = "HNK5QcWgZQdUAexNpD5aQinyEZULmh6stPCJGzsVyZAP0XFs"; // "your_secret_key"; //

  IWOTERRORCODE ec = IWOT_EC_SUCCESS;
  char * modelJSON  =  "{\"classID\":\"model_esp8266_led\",\"id\":\"esp_00001\",\"name\":\"ESP_Sample_Led\",\"actions\":{\"switch\":{\"values\":{\"ledState\":{\"type\":\"integer\"}}}}}";

  if(IWOT_EC_SUCCESS != iwot_util_create_config(
        accessKey, secretKey, host,  0, 
        modelJSON, 0, &iwotConfig)){
    
    return 0;
  }    

  if(IWOT_EC_SUCCESS != iwot_thing_init(iwotConfig, &thing)) {    
    
    return 0;
  }

  
  if(IWOT_EC_SUCCESS != iwot_thing_connect(thing, actionHandler, 0, 0)) {
    iwot_thing_uninit(&thing);
    
    return 0;
  }
  
  return 1;
}

/******************************************************************************
 * FunctionName : wait_for_network_on
 * Description  :  Waitting for network state till on line here
 * Parameters   : none
 * Returns      : 1 for ob line
*******************************************************************************/
int wait_for_network_on(){
    int onLine = 0;  

    // Wait till connect
    STATION_STATUS sta_stat = STATION_CONNECTING;
    int count = 0;
    do {
        vTaskDelay(1000/portTICK_RATE_MS);
        sta_stat = wifi_station_get_connect_status();
        count++;
    } while(STATION_CONNECTING == sta_stat);
    if (STATION_GOT_IP == sta_stat) {
      onLine = 1;
    }
    
    return onLine;
}

/******************************************************************************
 * FunctionName : main_task
 * Description  :  Main task
 * Parameters   : none
 * Returns      : none
*******************************************************************************/
void main_task(void * pvParameters)
{
  while (wait_for_network_on()) {

    if(connect_iWoT()) {
        printf("%s \n","MQTT connected.");

        while (1) {
            // printf("%s \n","Hello World.");
            vTaskDelay(5000 / portTICK_RATE_MS);
        } 
     }
  } 
}
/******************************************************************************
 * FunctionName : gpio_init
 * Description  : settings of controlling gpio environment here
 * Parameters   : none
 * Returns      : none
*******************************************************************************/
void gpio_init(){
  uint32 pin = 5; // D1 : GPIO 5
  gpio_pin_intr_state_set(pin, GPIO_PIN_INTR_DISABLE);
  uint16 gpio_pin_mask = BIT(pin); // GPIO_Pin_5;
  GPIO_AS_OUTPUT(gpio_pin_mask);  
}

/******************************************************************************
 * FunctionName : user_init
 * Description  : entry of user application, init user function here
 * Parameters   : none
 * Returns      : none
*******************************************************************************/
void user_init(void)
{
    //to avoid unreadable respondance. need #include "uart.h"
    uart_init_new();
    UART_SetBaudrate(UART0, BIT_RATE_115200); 
    UART_SetPrintPort(0);
       
    printf("SDK version:%s,%u\n", system_get_sdk_version(),__LINE__ );

    // Init gpio.
    gpio_init();

    // Create main task.
    xTaskCreate(main_task, "MAIN_TASK", 2000, NULL, tskIDLE_PRIORITY + 2, NULL);
}
