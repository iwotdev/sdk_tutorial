#!/bin/bash

python esptool.py -p /dev/ttyUSB0 write_flash --flash_mode qio --flash_size 32m-c1 0x0 ../images/eagle.flash.bin 0xFE000 ./blank.bin 0xFF000 ./blank.bin 0x20000 ../images/eagle.irom0text.bin 0x100000 ./spiff_rom.bin 0x3FC000 ./esp_init_data_default.bin 0x3FE000 ./blank.bin 0x3FF000 ./blank.bin
