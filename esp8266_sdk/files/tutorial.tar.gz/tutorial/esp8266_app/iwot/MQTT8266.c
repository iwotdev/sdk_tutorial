/*******************************************************************************
 * Copyright (c) 2014 IBM Corp.
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * and Eclipse Distribution License v1.0 which accompany this distribution.
 *
 * The Eclipse Public License is available at
 *    http://www.eclipse.org/legal/epl-v10.html
 * and the Eclipse Distribution License is available at
 *   http://www.eclipse.org/org/documents/edl-v10.php.
 *
 * Contributors:
 *    Allan Stockdill-Mander - initial API and implementation and/or initial documentation
 *******************************************************************************/

#include "MQTT8266.h"
#include <lwip/sockets.h>
#include <lwip/inet.h>
#include <lwip/netdb.h>
#include <lwip/sys.h>
#include "system_wrapper.h" 

void TimerInit(Timer* timer)
{
	timer->end_time = 0;
}
 
char TimerIsExpired(Timer* timer)
{
	portTickType now = xTaskGetTickCount();
  int32_t left = timer->end_time - now;

  return (left < 0);
}


void TimerCountdownMS(Timer* timer, unsigned int timeout)
{
  portTickType now = xTaskGetTickCount();
  timer->end_time = now + timeout / portTICK_RATE_MS;
}


void TimerCountdown(Timer* timer, unsigned int timeout)
{
	TimerCountdownMS(timer, timeout * 1000);
}


int TimerLeftMS(Timer* timer)
{
  portTickType now = xTaskGetTickCount();
  int32_t left = timer->end_time - now;
  return (left < 0) ? 0 : left * portTICK_RATE_MS;
}

#if IWOT_OPT_ENABLE_SSL	
int base64Decode (char *data, unsigned char *result, size_t *result_size)
{
	char *plain = 0;
  	char *token = 0;
  	const char *seq = "\\";
  	int len = strlen(data);
  	char *start = 0;
  	int ret = -1;
  	size_t size = 0; 
  	unsigned char *decode = 0;
  	int i = 0;
  	const char *exclusive[] = {
  		"-----BEGIN RSA PRIVATE KEY-----",
  		"n-----END RSA PRIVATE KEY-----",
  		"-----BEGIN TRUSTED CERTIFICATE-----",
  		"n-----END TRUSTED CERTIFICATE-----",
  	};

  	if (0 == (plain = (char *)malloc(len))) {
  		goto err_out;
  	}
  	memset(plain, 0, len);

  	token = strtok(data, seq);
  	while (0 != token) {
  		for (i = 0; i < 4; i ++) {
  			if (0 == strcmp(token, exclusive[i])) {
  				break;
  			}
  		}
		if (i == 1 || i == 3) {
			break;
		}
  		if (i == 4) {
	  		start = plain + strlen(plain);
	  		sprintf(start, "%s", &token[1]);  				
  		}
  		token = strtok(NULL, seq);
  	}

    ret = base64_decode(plain, strlen(plain), result, result_size);

err_out:
	if (0 != plain) {    
		free(plain);
	}
	return ret;
}

int linux_read_SSL(Network* n, unsigned char* buffer, int len, int timeout_ms)
{
	int ret = 0;
	int bytes_copied = 0;
	static uint8 *read_buf = NULL;
  static int buf_index = 0;
  static int buf_len = 0;

  struct timeval tv;
  fd_set fdset;
  
	if (timeout_ms == 0) {
		timeout_ms = 1000;
	}

  if (buf_len > 0) {
    if (buf_len - buf_index >= len) {
      memcpy(buffer, read_buf + buf_index, len);        
      buf_index += len;
      if (buf_index == buf_len) {
        buf_index = 0;
        buf_len = 0;
        read_buf = 0;
      }
      return len;
    } else {      
      memcpy(buffer, read_buf + buf_index, buf_len - buf_index); 
      buf_index = 0;
      buf_len = 0;
      read_buf = 0;
    }    
  }

  FD_ZERO(&fdset);
  FD_SET(n->my_socket, &fdset);
  tv.tv_sec = timeout_ms / 1000;
  tv.tv_usec = timeout_ms % 1000 * 1000;
  ret = select(n->my_socket + 1, &fdset, 0, 0, &tv);
  if ((ret > 0) && (FD_ISSET(n->my_socket, &fdset))) {
    while((buf_len = ssl_read(n->ssl, &read_buf)) >= 0) { 
      if (buf_len > 0) {
        if (buf_len >= len) {
          memcpy(buffer, read_buf, len);        
          ret = len;
          if (buf_len > len) {
            buf_index += len;  
          } else {
            buf_index = 0;
            buf_len = 0;
            read_buf = 0;
          }        
        }
        break;     
      }
    }     
  } else {
    ret = -1;
  }

	return ret;
}

int linux_write_SSL(Network* n, unsigned char* buffer, int len, int timeout_ms)
{
	int	ret = 0;

    while( ( ret = ssl_write(n->ssl, buffer, len ) ) <= 0 )
    {
      break;
    }

	return ret;
}

void NetworkDisconnect_SSL(Network* n)
{
  if(0 != n->ssl) {
    ssl_free(n->ssl);                  
  }
  if(0 != n->ssl_ctx) {
    ssl_ctx_free(n->ssl_ctx);
  }       
}

void NetworkInit_SSL(Network* n, char *cert, char *key)
{
	int ret = 0;
  int binLen = 1300;   
  uint8_t *binData = 0;

  n->enable_ssl = -1;

  if(0 == (binData = memory_alloc(1300))) {
    goto err_out;
  }
  
  if(0 == (n->ssl_ctx = ssl_ctx_new(SSL_NO_DEFAULT_KEY | SSL_SERVER_VERIFY_LATER, SSL_DEFAULT_CLNT_SESS))) {
    goto err_out;
  }

  if(0 != (ret = base64Decode(key, binData, &binLen))) {
    goto err_out; 
  }

  if(0 != (ret = ssl_obj_memory_load(n->ssl_ctx, SSL_OBJ_RSA_KEY, binData, binLen, 0))) {
    goto err_out; 
  }

  if(0 != (ret = base64Decode(cert, binData, &binLen))) {
    goto err_out; 
  }

  if(0 != (ret = ssl_obj_memory_load(n->ssl_ctx, SSL_OBJ_X509_CACERT, binData, binLen, 0))) {
    goto err_out; 
  }      

  n->enable_ssl = 1;
	n->mqttread = linux_read_SSL;
	n->mqttwrite = linux_write_SSL;	    

err_out:	
	if (0 != binData) {
		memory_free(binData);
	}

	if (-1 == n->enable_ssl) {
		NetworkDisconnect_SSL(n);	
	} else {
    memory_free(cert);
    memory_free(key);
  }    
}

int NetworkConnect_SSL(Network* n, char* addr, int port)
{
	int ret = -1;
	char port_str[6];
	uint32_t flags = 0;
printf("[Free Heap] before ssl_client_new %d\n", system_get_free_heap_size());
  if(0 == (n->ssl = ssl_client_new(n->ssl_ctx, n->my_socket, NULL, 0))) {
    goto err_out;
  }
printf("[Free Heap] before ssl_handshake_status %d\n", system_get_free_heap_size());
  if (SSL_OK == ssl_handshake_status(n->ssl)){
    x509_free(n->ssl->x509_ctx);   
  }

  ret = 0;
err_out:
  if (-1 == ret) {
    NetworkDisconnect_SSL(n); 
  }

	return ret;
}
#endif


int linux_read(Network* n, unsigned char* buffer, int len, int timeout_ms)
{
  if (timeout_ms <= 0) {
    return 0;
  }

	setsockopt(n->my_socket, SOL_SOCKET, SO_RCVTIMEO, (char *)&timeout_ms, sizeof(int));

	int bytes = 0;
	while (bytes < len)
	{
		int rc = recv(n->my_socket, &buffer[bytes], (size_t)(len - bytes), 0);
		if (rc == -1)
		{
			if (errno != ENOTCONN && errno != ECONNRESET)
			{
				bytes = -1;
				break;
			}
		}
		else
			bytes += rc;
	}
	return bytes;
}


int linux_write(Network* n, unsigned char* buffer, int len, int timeout_ms)
{
  if (timeout_ms <= 0) {
    return 0;
  }  

	setsockopt(n->my_socket, SOL_SOCKET, SO_RCVTIMEO, (char *)&timeout_ms,sizeof(int));
	int	rc = write(n->my_socket, buffer, len);
	return rc;
}

void NetworkInit(Network* n, char *cert, char *key)
{
	n->my_socket = 0;
	n->mqttread = linux_read;
	n->mqttwrite = linux_write;	
	
#if IWOT_OPT_ENABLE_SSL
	n->enable_ssl = 0;
	if (0 != cert && 0 != key) {
		NetworkInit_SSL(n, cert, key);
	}	
#endif
}

int NetworkConnect(Network* n, char* addr, int port)
{
	int type = SOCK_STREAM;
	struct sockaddr_in address;
	int rc = -1;
	sa_family_t family = AF_INET;
  struct addrinfo *p = NULL;
	struct addrinfo *result = NULL;
	struct addrinfo hints = {0, AF_UNSPEC, SOCK_STREAM, IPPROTO_TCP, 0, NULL, NULL, NULL};
  char port_str[6];

  struct sockaddr_in client_addr;
  uint32_t sin_addr;

  sprintf(port_str, "%d", port);
  if ((rc = getaddrinfo(addr, port_str, &hints, &result)) != 0) {
    return rc;
  }

  for (p = result; p != NULL; p = p->ai_next) {
    if ((n->my_socket = socket(p->ai_family, p->ai_socktype, p->ai_protocol)) == -1) {
      continue;
    }

    if (connect(n->my_socket, p->ai_addr, p->ai_addrlen) == -1) {
      close(n->my_socket);
      continue;
    }

    rc = 0;
    break;
  }

#if IWOT_OPT_ENABLE_SSL
  if (1 == n->enable_ssl) {
    return NetworkConnect_SSL(n, addr, port);
  } 
#endif    

  return rc;
}


void NetworkDisconnect(Network* n)
{
	close(n->my_socket);

#if IWOT_OPT_ENABLE_SSL
	if (1 == n->enable_ssl) {
		return NetworkDisconnect_SSL(n);
	}
#endif	
}
