#ifndef _IWOT_JSON_HEADER_
#define _IWOT_JSON_HEADER_

#include "iwot_util.h"

#ifdef __cplusplus 
extern "C" { 
#endif

typedef struct _connectOpt {
	char *host;
	int port;
	char *protocol;
	char *token;
} CONNECTOPT;

IWOTERRORCODE json_parse_var_object(char *text, IWOTVAROBJECT **result, int *qos);
IWOTERRORCODE json_parse_connect_opt(char *text, CONNECTOPT **result);
IWOTERRORCODE json_parse_connect_opt_ex(char *text, CONNECTOPT **result, char **cert, char **key);
IWOTERRORCODE json_parse_connect_package(char *text, CONNECTOPT **opt, char **cert, char **key, IWOTMODEL **model);
IWOTERRORCODE json_parse_model(char *text, IWOTMODEL **result);

#ifdef __cplusplus 
} 
#endif 

#endif 