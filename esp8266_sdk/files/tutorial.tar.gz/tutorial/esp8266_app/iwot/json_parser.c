#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "json_parser.h"
#include "system_wrapper.h"
#include "jsmn.h"

typedef enum {
    JSON_INTEGER = 0,
    JSON_STRING,
    JSON_BOOLEAN,
	JSON_FLOAT,
    JSON_OBJECT,
    JSON_ARRAY,
    JSON_NULL,
    JSON_UNDEFINED
} JSONITEMTYPE;  

typedef struct _jsonItem {
    char* key;
    JSONITEMTYPE type;
    union _jsonItemValue {
        int integer;
        struct _jsonItem *items;
        char *string;
#if IWOT_OPT_ENABLE_FPU     
        double floating;
#endif        
    } value;
    int length;
    /*struct _jsonItem *parent;*/
} JSONITEM;

void _json_print_items (JSONITEM *items, int level, int arrayMode)
{
	int i;		
	char *space = (char*)memory_alloc(sizeof(char) * (level * 4) + 1);
	memset(space, ' ', sizeof(char) * (level * 4));
	space[level * 4] = '\0';
	JSONITEM *item;
		
	if (0 != arrayMode) {		
		if (JSON_INTEGER == items->type) {
			printf("%s\"%s\":%d,\n", space, items->key, items->value.integer);
		} else if (JSON_STRING == items->type) {
			printf("%s\"%s\":\"%s\",\n", space, items->key, items->value.string);
		} else if (JSON_BOOLEAN == items->type) {
			printf("%s\"%s\":%s,\n", space, items->key, 1 == items->value.integer ? "true" : "false");
#if IWOT_OPT_ENABLE_FPU 		
		} else if (JSON_FLOAT == items->type) { 			
			printf("%s\"%s\":%lf,\n", space, items->key, items->value.floating);
#endif			
		} else if (JSON_OBJECT == items->type) {
			printf("%s\"%s\":\n%s{\n", space, items->key, space);
			item = items->value.items;
			for (i = 0; i < items->length; i++, item++) {
				_json_print_items (item, level + 1, 1);					
			}						
			printf("%s},\n", space);			
		} else if (JSON_ARRAY == items->type) {
			printf("%s\"%s\":\n%s[\n", space, items->key, space);
			item = items->value.items;
			for (i = 0; i < items->length; i++, item++) {
				_json_print_items (item, level + 1, 0);
			}			
			printf("%s],\n", space);
		} else if (JSON_NULL == items->type) {
			printf("%s\"%s\":null,\n", space, items->key);
		} else if (JSON_UNDEFINED == items->type) {
			printf("%s\"%s\":undefined,\n", space, items->key);
		}
	} else {
		if (JSON_INTEGER == items->type) {
			printf("%s%d,\n", space, items->value.integer);
		} else if (JSON_STRING == items->type) {
			printf("%s\"%s\",\n", space, items->value.string);
		} else if (JSON_BOOLEAN == items->type) {
			printf("%s%s,\n", space, 1 == items->value.integer ? "true" : "false");
#if IWOT_OPT_ENABLE_FPU 		
		} else if (JSON_FLOAT == items->type) {
			printf("%s%lf,\n", space, items->value.floating);
#endif			
		} else if (JSON_OBJECT == items->type) {
			printf("%s{\n", space);
			item = items->value.items;
			for (i = 0; i < items->length; i++, item++) {
				_json_print_items (item, level + 1, 1);
			}			
			printf("%s},\n", space);			
		} else if (JSON_ARRAY == items->type) {
			printf("%s[\n", space);
			item = items->value.items;
			for (i = 0; i < items->length; i++, item++) {
				_json_print_items (item, level + 1, 0);
			}			
			printf("%s],\n", space);
		} else if (JSON_NULL == items->type) {
			printf("%snull,\n", space);
		} else if (JSON_UNDEFINED == items->type) {
			printf("%sundefined,\n", space);
		}			
	}	
	
	memory_free(space);
}

JSONITEM * _json_contain_items (JSONITEM *items, const char* key)
{
	int i = 0;	
	JSONITEM *item;
	
	if (JSON_OBJECT != items->type) { return 0; }
	
	item = items->value.items;
	for (i = 0; i < items->length; i++, item++) {
		if (0 == strcmp(item->key, key)) {
			return item;
		}
	}
	
	return 0;
}

char *_json_get_items_value_string (JSONITEM *items, const char* key) 
{
	JSONITEM *item = 0;
	
	if (0 != (item = _json_contain_items(items, key))) {		
		if (JSON_STRING != item->type) { return 0; }
		return item->value.string;	
	}
	return 0;
}

int _json_get_items_value_integer (JSONITEM *items, const char* key) 
{
	JSONITEM *item = 0;
	
	if (0 != (item = _json_contain_items(items, key))) {
		if (JSON_INTEGER != item->type) { return 0xFFFFFFFF; }
		return item->value.integer;	
	}
	return 0xFFFFFFFF;
}

int _json_get_items_value_boolean (JSONITEM *items, const char* key) 
{
	JSONITEM *item = 0;
	
	if (0 != (item = _json_contain_items(items, key))) {
		if (JSON_BOOLEAN != item->type) { return 0xFFFFFFFF; }
		return item->value.integer;	
	}
	return 0xFFFFFFFF;
}

#if IWOT_OPT_ENABLE_FPU 
double _json_get_items_value_floating (JSONITEM *items, const char* key) 
{
	JSONITEM *item = 0;
	
	if (0 != (item = _json_contain_items(items, key))) {
		if (JSON_FLOAT != item->type) { return 0xFFFFFFFF; }
		return item->value.floating;	
	}
	return 0xFFFFFFFF;
}
#endif

JSONITEM* _json_get_items_value_object (JSONITEM *items, const char* key) 
{
	JSONITEM *item = 0;
	
	if (0 != (item = _json_contain_items(items, key))) {
		if (JSON_OBJECT != item->type) { return 0; }
		return item;	
	}
	return 0;
}

JSONITEM* _json_get_items_value_array (JSONITEM *items, const char* key) 
{
	JSONITEM *item = 0;
	
	if (0 != (item = _json_contain_items(items, key))) {
		if (JSON_ARRAY != item->type) { return 0; }
		return item;	
	}
	return 0;
}

void _json_free_items (JSONITEM **items, int level)
{
	int i = 0;
	JSONITEM *next;
	JSONITEM *item = *items;
	
	if (0 == item) { return; }
						
	iwot_util_free_string(&item->key);
	if (JSON_STRING == item->type) {
		iwot_util_free_string(&item->value.string);			
	} else if (JSON_OBJECT == item->type || JSON_ARRAY == item->type) {
		next = item->value.items;
		for (i = 0; i < item->length; i++, next++) {
			_json_free_items (&next, level + 1);			
		}
		memory_free(item->value.items);
		item->value.items = 0;
		
		if (0 == level) { //root
			memory_free(*items);
			*items = 0;
		}					
	}		
}

jsmntok_t* _json_create_items (const char* text, JSONITEM **result, jsmntok_t *tokens, int level, int noPrimitive)
{
	IWOTERRORCODE ec = IWOT_EC_SUCCESS;
	int i, size, length;
	jsmntok_t *token = tokens;
	JSONITEM *items = 0, *item = 0;

	char* cvt_s;		
	int cvt_i = 0;

#if IWOT_OPT_ENABLE_FPU 
	double cvt_lf;	
#endif	
	
	if (0 == tokens) {
		return token;
	}
	
	if (0 == level) { //root
		length = 1;
	} else {
		length = tokens->size;		
		token++;							
	}
	
	if (0 == length) {
		return --token;
	}
	
	size = sizeof(JSONITEM) * length;
	if (0 == (items = (JSONITEM*)memory_alloc(size))) {
		ec = IWOT_EC_INSUFFICIENT_MEMORY;
		goto err_out;
	}	
	memset(items, 0, size);
		
    item = items;				
	for (i = 0; i < length; i++, token++, item++) {		
		if (JSMN_ARRAY != tokens->type && 0 != level) {
			if(IWOT_EC_SUCCESS != (ec = iwot_util_copy_string_partial(text, &item->key, token->start, token->end - token->start))) {
				goto err_out;
			}
			token++;			
		}					
		if (JSMN_UNDEFINED == token->type) {
			item->type = JSON_UNDEFINED;
		} else if (JSMN_OBJECT == token->type) {
			item->type = JSON_OBJECT;
			item->length = token->size;	
			if (0 == item->length) {
				continue;
			}		
			if (0 == (token = _json_create_items (text, &item->value.items, token, level + 1, noPrimitive))) {
				goto err_out;
			} 
		} else if (JSMN_ARRAY == token->type) {
			item->type = JSON_ARRAY;
			item->length = token->size;		
			if (0 == item->length) {
				continue;
			}		
			if (0 == (token = _json_create_items (text, &item->value.items, token, level + 1, noPrimitive))) {
				goto err_out;
			} 
		} else if (JSMN_STRING == token->type) {
			item->type = JSON_STRING;			
			if(IWOT_EC_SUCCESS != (ec = iwot_util_copy_string_partial(text, &item->value.string, token->start, token->end - token->start))) {
				goto err_out;
			}						 
		} else if (JSMN_PRIMITIVE == token->type) {
			if (0 == noPrimitive) {
				item->type = JSON_STRING;			
				if(IWOT_EC_SUCCESS != (ec = iwot_util_copy_string_partial(text, &item->value.string, token->start, token->end - token->start))) {
					goto err_out;
				}				
			} else {
				switch(text[token->start]) {
					case 't':
						item->type = JSON_BOOLEAN;
						item->value.integer = 1;
						break;
					case 'f':
						item->type = JSON_BOOLEAN;
						item->value.integer = 0;
						break;
					case 'n':	
						item->type = JSON_NULL;
						break;				
					default:
						if(IWOT_EC_SUCCESS != (ec = iwot_util_copy_string_partial(text, &cvt_s, token->start, token->end - token->start))) {
							goto err_out;
						}	
#if IWOT_OPT_ENABLE_FPU 
						iwot_util_string_to_number(cvt_s, &cvt_i, &cvt_lf);
						iwot_util_free_string(&cvt_s);
						if (cvt_lf == 0xFFFFFFFF) {
							item->type = JSON_INTEGER;
							item->value.integer = cvt_i;						
						} else {
							item->type = JSON_FLOAT;
							item->value.floating = cvt_lf;						
						}	
#else
						iwot_util_string_to_integer(cvt_s, &cvt_i);
						iwot_util_free_string(&cvt_s);
						item->type = JSON_INTEGER;
						item->value.integer = cvt_i;						
#endif								
						break;					
				}				
			}
		} else {
			ec = IWOT_EC_JSON_PARSE_FAILED;
			goto err_out;
		}
	}
	
	*result = items;
	return --token;
	
err_out:
	if (0 != items) {
		_json_free_items (&items, level);	
	}
	return 0;
}

IWOTERRORCODE _json_parse (const char* text, JSONITEM **result, int noPrimitive)
{
	IWOTERRORCODE ec = IWOT_EC_SUCCESS;
    jsmn_parser parser;
    int tokenSize = 32;
    jsmntok_t *tokens = 0;	
	int len, total, size;
	JSONITEM *items = 0;

	//for debug
	/*char debug_text[4096];
	jsmntok_t *debug_token = 0;	
	int i;*/
    
 	jsmn_init(&parser);
	size = sizeof(jsmntok_t) * tokenSize;
	if (0 == (tokens = (jsmntok_t *)memory_alloc(size))) {
		ec = IWOT_EC_INSUFFICIENT_MEMORY;
		goto err_out;
	}	
	memset(tokens, 0, size);
	while(-1 == (total = jsmn_parse(&parser, text, strlen(text), tokens, tokenSize))) {
		memory_free(tokens);
		tokenSize += 32;
		jsmn_init(&parser);
		size = sizeof(jsmntok_t) * tokenSize;		
		if (0 == (tokens = (jsmntok_t *)memory_alloc(size))) {
			ec = IWOT_EC_INSUFFICIENT_MEMORY;
			goto err_out;
		}			
		memset(tokens, 0, size);
	}	
	if (-2 == total) {
		ec = IWOT_EC_JSON_PARSE_FAILED;
		goto err_out;		
	}

	//for debug
	/*debug_log("item count=%d\n", total);		
	for (i =0, debug_token = tokens; i < total; i++, debug_token++) {
		memset(debug_text, 0, 4096);		
		memcpy(debug_text, &text[debug_token->start], debug_token->end - debug_token->start);
		printf("[%d] %s\n", i, debug_text);
	}*/

	if (0 == _json_create_items (text, &items, tokens, 0, noPrimitive)) {
		ec = IWOT_EC_INSUFFICIENT_MEMORY;
		goto err_out;
	}   		
	//_json_print_items (items, 0, 0); //for debug
		
	*result = items;
			
err_out:
	if (0 != tokens) {
		memory_free(tokens);	
	}	

	if (ec != IWOT_EC_SUCCESS) {
		debug_log("_json_parse failed. error code=%d", ec);
	}
		
	return ec;	
}

IWOTERRORCODE json_parse_connect_opt(char *text, CONNECTOPT **result)
{
	return json_parse_connect_opt_ex(text, result, 0, 0);
	/*IWOTERRORCODE ec = IWOT_EC_SUCCESS;  
	int size = sizeof(CONNECTOPT);	
	CONNECTOPT *opt = 0;
	char *value_s = 0;
	int value_i = 0xFFFFFFFF;

	JSONITEM *root = 0;
	if(IWOT_EC_SUCCESS != (ec = _json_parse(text, &root, 1))) {
		goto err_out;		
	}

	if (0 == (opt = (CONNECTOPT*)memory_alloc(size))) {
		ec = IWOT_EC_INSUFFICIENT_MEMORY;
		goto err_out;     
	}

	memset(opt, 0, size);

	if (0 == (value_s = _json_get_items_value_string(root, "host"))) {
		ec = IWOT_EC_INVALID_DATA;
		goto err_out;
	}
	if(IWOT_EC_SUCCESS != (ec = iwot_util_copy_string(value_s, &opt->host))) {
		goto err_out;     
	}
	if (0 == (value_i = _json_get_items_value_integer(root, "port"))) {
		ec = IWOT_EC_INVALID_DATA;
		goto err_out;
	}	
	opt->port = value_i;
	if (0 == (value_s = _json_get_items_value_string(root, "protocol"))) {
		ec = IWOT_EC_INVALID_DATA;
		goto err_out;
	}	
	if(IWOT_EC_SUCCESS != (ec = iwot_util_copy_string(value_s, &opt->protocol))) {
		goto err_out;     
	}
	if (0 == (value_s = _json_get_items_value_string(root, "token"))) {
		ec = IWOT_EC_INVALID_DATA;
		goto err_out;
	}	
	if(IWOT_EC_SUCCESS != (ec = iwot_util_copy_string(value_s, &opt->token))) {
		goto err_out;     
	}

	debug_log("connect options: [%s, %d, %s, %s]", opt->host, opt->port, opt->protocol, opt->token);

	*result = opt;

err_out:	
	if (IWOT_EC_SUCCESS != ec && 0 != opt) {
		if (0 != opt->host) {
			iwot_util_free_string(&opt->host);
		}
		if (0 != opt->protocol) {
			iwot_util_free_string(&opt->protocol);
		}
		if (0 != opt->token) {
			iwot_util_free_string(&opt->token);
		}
		memory_free(opt);
	}
	
	if (0 != root) {
		_json_free_items(&root, 0);
	}

	return ec;*/
}

IWOTERRORCODE json_parse_var_object(char *text, IWOTVAROBJECT **result, int *qos) 
{
	IWOTERRORCODE ec = IWOT_EC_SUCCESS;  
	IWOTVAROBJECT *object = 0;
	char *type[3] = {"properties", "actions", "buildins"};
	int type_count = sizeof(type) / sizeof(type[1]);
	char *QoS = 0;
	
	JSONITEM *root = 0;
	if(IWOT_EC_SUCCESS != (ec = _json_parse(text, &root, 0))) {
		goto err_out;		
	}	

	for (int i = 0; i < type_count; i++) {
		JSONITEM *properties = 0;
		if (0 != (properties = _json_get_items_value_object(root, type[i]))) {
			JSONITEM *v = 0;
			if (IWOT_EC_SUCCESS != (ec = iwot_util_create_var_object(type[i], properties->length, &object))) {
				goto err_out;
			}
			if(0 != (QoS = _json_get_items_value_string(root, "QoS"))) {
				sscanf(QoS, "%d", qos);
			} else {
				*qos = 0;
			}						
			v = properties->value.items;
			for (int j = 0; j < properties->length; j++, v++) {
				JSONITEM *values = 0;
				if (0 != (values = _json_get_items_value_object(v, "values"))) {
					JSONITEM *v2 = 0;
					if (IWOT_EC_SUCCESS != (ec = iwot_util_create_var_group(
						v->key, 
						values->length,
						_json_get_items_value_string(v, "timestamp"), 
						_json_get_items_value_string(v, "status"),
						_json_get_items_value_string(v, "id"),
						&object->groups[j]))) {
						goto err_out;
					}	
					v2 = values->value.items;
					for (int k = 0; k < values->length; k++, v2++) {
						if (IWOT_EC_SUCCESS != (ec = iwot_util_create_var_item_string(v2->key, v2->value.string, &object->groups[j]->items[k]))) {
							goto err_out;
						}						
					}												
				} else {
					if (IWOT_EC_SUCCESS != (ec = iwot_util_create_var_group(
						v->key, 
						0,
						_json_get_items_value_string(v, "timestamp"), 
						_json_get_items_value_string(v, "status"),
						_json_get_items_value_string(v, "id"),
						&object->groups[j]))) {
						goto err_out;
					}					
				}
			}	 		
			break;
		}	
	}

	*result = object;

err_out:
	if (IWOT_EC_SUCCESS != ec && 0 != object) {
		iwot_util_free_var_object(&object);
	}
	
	if (0 != root) {
		_json_free_items(&root, 0);
	}	
	
	return ec;
}

IWOTERRORCODE json_parse_model(char *text, IWOTMODEL **result)
{
	IWOTERRORCODE ec = IWOT_EC_SUCCESS;
	IWOTMODEL *model = 0;
	JSONITEM *res[3];
	char *attrs[3] = {"actions", "events", "properties"};
	
    JSONITEM *root = 0;
	JSONITEM *links = 0;
	
	JSONITEM *resource = 0;
	IWOTVARDEF **var;
		
	if(IWOT_EC_SUCCESS != (ec = _json_parse(text, &root, 1))) {
		goto err_out;		
	}
					
	if (0 != (links = _json_get_items_value_object(root, "links"))) {		
		for (int k = 0; k < 3; k++) {									
			if (0 != (resource = _json_get_items_value_object(links, attrs[k]))) {
				res[k] = _json_get_items_value_object(resource, "resources");				
			} else {
				res[k] = 0;
			}			
		}
	} else {
		res[0] = _json_get_items_value_object(root, "actions");				
		res[1] = _json_get_items_value_object(root, "events");				
		res[2] = _json_get_items_value_object(root, "properties");						
	}
					
	if (IWOT_EC_SUCCESS != (ec = iwot_util_create_model(
		_json_get_items_value_string(root, "id"), 
		_json_get_items_value_string(root, "classID"),
		_json_get_items_value_string(root, "createdAt"),
		_json_get_items_value_string(root, "updatedAt"),
		_json_get_items_value_string(root, "name"),
		_json_get_items_value_string(root, "description"),
		0, 0, 0, 0, 
		0 == res[0] ? 0 : res[0]->length,
		0 == res[1] ? 0 : res[1]->length,
		0 == res[2] ? 0 : res[2]->length,  
		0, &model))) {
		goto err_out;
	}
			
	for (int k = 0; k < 3; k++) {			
		if (k == 0) {
			var = model->actions;
		} if (k == 1) {
			var = model->events;
		} if (k == 2) {
			var = model->properties;
		} 
		if (0 != var) {
			resource = res[k]->value.items;
			JSONITEM *v = 0;
			JSONITEM *v2 = 0;
			for (int i = 0; i < res[k]->length; i++, resource++) {					
				if (0 != (v = _json_get_items_value_object(resource, "values"))) {
					if (IWOT_EC_SUCCESS != (ec = iwot_util_create_var_def(
						resource->key,
						_json_get_items_value_string(resource, "name"), 
						_json_get_items_value_string(resource, "description"), 
						v->length, &var[i]))) {
						goto err_out;
					}	
					v2 = v->value.items;						
					for (int j = 0; j < v->length; j++, v2++) {							
						char **enum_array = 0;								
						JSONITEM *enumerate;
						if (0 != (enumerate = _json_get_items_value_object(v2, "enum"))) {
							if (enumerate->length > 0) {
								if (IWOT_EC_SUCCESS != (ec = iwot_util_create_string_array(enumerate->length, &enum_array))) {
									goto err_out;
								}											
								char *enumText;										
								for (int m = 0; m < enumerate->length; m++) {
									enumText = enumerate->value.items[m].value.string;										
									if (0 != enumText && IWOT_EC_SUCCESS != (ec = iwot_util_copy_string(enumText, &enum_array[m]))) {
										goto err_out;
									}																															
								}
							}
						}
						if (IWOT_EC_SUCCESS != (ec = iwot_util_create_var_value(
							v2->key, 
							_json_get_items_value_string(v2, "name"),
							_json_get_items_value_string(v2, "description"),
							_json_get_items_value_string(v2, "type"),
							_json_get_items_value_string(v2, "unit"),
							_json_get_items_value_boolean(v2, "required"),
							_json_get_items_value_integer(v2, "minValue"),
							_json_get_items_value_integer(v2, "maxValue"),
							enum_array, 
							0 == enumerate ? 0 : enumerate->length, 
							&var[i]->values[j]))) {
							goto err_out;
						}																			

						if (0 != enum_array) {
							iwot_util_free_string_array(&enum_array, enumerate->length);	
						}													
					}																			
				}
			}
		}
	}				

	if (model == 0 || model->id == 0 || model->classID == 0) {
		ec = IWOT_EC_JSON_PARSE_FAILED;
		goto err_out;
	}
	
	*result = model;

err_out:	
	if (IWOT_EC_SUCCESS != ec && 0 != model) {
		iwot_util_free_model(&model);
	}
	
	if (0 != root) {
		_json_free_items(&root, 0);
	}
		
	return ec;		
}

IWOTERRORCODE json_parse_connect_opt_ex(char *text, CONNECTOPT **result, char **cert, char **key)
{
	IWOTERRORCODE ec = IWOT_EC_SUCCESS;  
	int size = sizeof(CONNECTOPT);	
	CONNECTOPT *opt = 0;
	char *value_s = 0;
	int value_i = 0xFFFFFFFF;
	char *clientCert = 0;
	char *clientKey = 0;

	JSONITEM *root = 0;
	if(IWOT_EC_SUCCESS != (ec = _json_parse(text, &root, 1))) {
		goto err_out;		
	}

	if (0 == (opt = (CONNECTOPT*)memory_alloc(size))) {
		ec = IWOT_EC_INSUFFICIENT_MEMORY;
		goto err_out;     
	}

	memset(opt, 0, size);

	if (0 == (value_s = _json_get_items_value_string(root, "host"))) {
		ec = IWOT_EC_INVALID_DATA;
		goto err_out;
	}
	if(IWOT_EC_SUCCESS != (ec = iwot_util_copy_string(value_s, &opt->host))) {
		goto err_out;     
	}
	if (0 == (value_i = _json_get_items_value_integer(root, "port"))) {
		ec = IWOT_EC_INVALID_DATA;
		goto err_out;
	}	
	opt->port = value_i;
	if (0 == (value_s = _json_get_items_value_string(root, "protocol"))) {
		ec = IWOT_EC_INVALID_DATA;
		goto err_out;
	}	
	if(IWOT_EC_SUCCESS != (ec = iwot_util_copy_string(value_s, &opt->protocol))) {
		goto err_out;     
	}
	if (0 == (value_s = _json_get_items_value_string(root, "token"))) {
		ec = IWOT_EC_INVALID_DATA;
		goto err_out;
	}	
	if(IWOT_EC_SUCCESS != (ec = iwot_util_copy_string(value_s, &opt->token))) {
		goto err_out;     
	}
	if (0 != cert) {
		if (0 == (value_s = _json_get_items_value_string(root, "clientCert"))) {
			ec = IWOT_EC_INVALID_DATA;
			goto err_out;
		}	
		if(IWOT_EC_SUCCESS != (ec = iwot_util_copy_string(value_s, &clientCert))) {
			goto err_out;     
		}		
	}
	if (0 != key) {
		if (0 == (value_s = _json_get_items_value_string(root, "clientKey"))) {
			ec = IWOT_EC_INVALID_DATA;
			goto err_out;
		}	
		if(IWOT_EC_SUCCESS != (ec = iwot_util_copy_string(value_s, &clientKey))) {
			goto err_out;     
		}			
	}
	debug_log("connect options: [%s, %d, %s, %s]", opt->host, opt->port, opt->protocol, opt->token);

	*result = opt;
	if (0 != cert) {
		*cert = clientCert;
	}
	if (0 != key) {
		*key = clientKey;
	}

err_out:	
	if (IWOT_EC_SUCCESS != ec) {
		if (0 != opt) {
			if (0 != opt->host) {
				iwot_util_free_string(&opt->host);
			}
			if (0 != opt->protocol) {
				iwot_util_free_string(&opt->protocol);
			}
			if (0 != opt->token) {
				iwot_util_free_string(&opt->token);
			}
			memory_free(opt);			
		}
		if (0 != clientCert) {
			iwot_util_free_string(&clientCert);
		}
		if (0 != clientKey) {
			iwot_util_free_string(&clientKey);
		}		
	}
	
	if (0 != root) {
		_json_free_items(&root, 0);
	}

	return ec;
}

IWOTERRORCODE json_parse_connect_package(char *text, CONNECTOPT **opt, char **cert, char **key, IWOTMODEL **model)
{
	IWOTERRORCODE ec = IWOT_EC_NULL_DATA;
			 
	char *token = 0;  
	int connectOptStart = 0;
	int connectOptEnd = 0;
	int modelStart = 0;
	int modelEnd = 0;
	char c = 0;
		
	token = strtok(text, ":");
	if (0 == strcmp(token, "{\"connectOpt\"")) {
		token = strtok(NULL, "}");		 		
		connectOptStart = 14;		
		connectOptEnd = strlen(token) + connectOptStart + 1;
		text[connectOptStart - 1] = ':';
		text[connectOptEnd - 1] = '}';
	}
	token = strtok(NULL, ":");
	if (0 == strcmp(token, ",\"model\"")) {
		modelStart = connectOptEnd + 9;
		text[modelStart - 1] = ':';						
		modelEnd = strlen(text) - 1;
	}		

	if (0 != connectOptEnd) {
		c = text[connectOptEnd]; 
		text[connectOptEnd] = '\0';	
		if(IWOT_EC_SUCCESS != (ec = json_parse_connect_opt_ex(&text[connectOptStart], opt, cert, key))) {
			return ec;
		}
		text[connectOptEnd] = c;
	}
	if (0 != modelEnd) {
		c = text[modelEnd];
		text[modelEnd] = '\0';
		ec = json_parse_model(&text[modelStart], model);
		text[modelEnd] = c;		
	}	
	
	return ec;
}
