#include <FreeRTOS.h>
#include <task.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>
//#include <unistd.h>
#include "system_wrapper.h"
#include "iwot_opt.h"

void debug_log(const char *format, ...)
{
#if IWOT_OPT_ENABLE_DEBUG
   va_list arg;
   char output[256];
   memset(output, 0, 256);

   va_start (arg, format);   
   vsprintf(output, format, arg);
   va_end (arg);

   printf(output);  
   printf("\n");	
#endif
}

void doze_off(int ms)
{
   vTaskDelay(ms / portTICK_RATE_MS);     
}

void* memory_alloc(size_t s)
{
   return (void*)zalloc(s);
}

void memory_free(void *p)
{
   free(p);
}