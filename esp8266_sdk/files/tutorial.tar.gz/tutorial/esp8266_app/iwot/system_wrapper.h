#ifndef _IWOT_LOG_HEADER_
#define _IWOT_LOG_HEADER_

#ifdef __cplusplus 
extern "C" { 
#endif

void debug_log(const char *format, ...);
void doze_off(int ms);
void* memory_alloc(size_t s);
void memory_free(void *p);

#ifdef __cplusplus 
} 
#endif 

#endif 