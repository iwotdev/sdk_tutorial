#!/bin/bash

python esptool.py -p /dev/ttyUSB0 write_flash --flash_mode qio --flash_size 32m-c1 0x0 ../images/eagle.flash.bin 0x20000 ../images/eagle.irom0text.bin
