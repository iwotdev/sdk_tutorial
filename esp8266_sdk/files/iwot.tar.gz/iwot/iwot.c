#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "http_downloader.h"
#include "mqtt_wrapper.h"  
#include "system_wrapper.h"
#include "json_parser.h"
#include "iwot.h"

typedef struct _thingsub {
	int length;
	int used;
	char **topic;
	THING **thing;
}THINGSUB;

THINGSUB *singletonThingSub = 0;

void _thingsub_remove_thing(THING *thing) 
{	
	THINGSUB *sub = singletonThingSub;		
	int i = 0;

	if (0 != sub) {
		for (i = 0; i < sub->used; i++) {
			if (sub->thing[i] == thing) {
				memory_free(sub->topic[i]);
				sub->topic[i] = 0;
				sub->thing[i] = 0;
			}
		}
	}
}

void _thingsub_free(THINGSUB **result) 
{	
	THINGSUB *sub = *result;		

	if (0 != sub) {
		if (0 != sub->topic) {
			memory_free(sub->topic);
		}
		if (0 != sub->thing) {
			memory_free(sub->thing);
		}
		memory_free(sub);
	}
	*result = 0;
}

IWOTERRORCODE _thingsub_alloc(THINGSUB **result, int length) 
{
	IWOTERRORCODE ec = IWOT_EC_SUCCESS;
	THINGSUB *sub = 0;		
	if (0 == (sub = (THINGSUB*)memory_alloc(sizeof(THINGSUB)))) {
		ec = IWOT_EC_INSUFFICIENT_MEMORY;
		goto err_out;
	}
	memset(sub, 0, sizeof(THINGSUB));
	sub->length = length;
	if (0 == (sub->topic = (char**)memory_alloc(sizeof(char*) * sub->length))) {
		ec = IWOT_EC_INSUFFICIENT_MEMORY;
		goto err_out;
	}		
	if (0 == (sub->thing = (THING**)memory_alloc(sizeof(THING*) * sub->length))) {
		ec = IWOT_EC_INSUFFICIENT_MEMORY;
		goto err_out;
	}	
	*result = sub;

	return ec;
err_out:
	_thingsub_free(&sub);
	return ec;
}

IWOTERRORCODE _thingsub_get(THINGSUB **result) 
{
	IWOTERRORCODE ec = IWOT_EC_SUCCESS;
	THINGSUB *sub = singletonThingSub;	
	THINGSUB *subNew = 0;
	int i = 0;

	if (0 == sub) {
		if(IWOT_EC_SUCCESS == (ec = _thingsub_alloc(&sub, 10))) {
			singletonThingSub = sub;	
		}		
	} else if (sub->length == sub->used + 1) {
		if(IWOT_EC_SUCCESS == (ec = _thingsub_alloc(&subNew, sub->length + 10))) {
			subNew->length = sub->length;
			subNew->used = sub->used;
			for (i = 0; i < sub->used; i++) {
				subNew->topic[i] = sub->topic[i];
				subNew->thing[i] = sub->thing[i];
			}
			_thingsub_free(&sub);
			sub = subNew;
			singletonThingSub = subNew;	
		}		
	}
	*result = sub;

	return ec;
}
/*
IWOTERRORCODE _thingsub_get(THINGSUB **result) 
{
	IWOTERRORCODE ec = IWOT_EC_SUCCESS;
	THINGSUB *sub = singletonThingSub;	
	if (0 == sub) {
		if (0 == (sub = (THINGSUB*)memory_alloc(sizeof(THINGSUB)))) {
			ec = IWOT_EC_INSUFFICIENT_MEMORY;
			goto err_out;
		}
		memset(sub, 0, sizeof(THINGSUB));
		sub->length = 10;
		if (0 == (sub->topic = (char**)memory_alloc(sizeof(char*) * sub->length))) {
			ec = IWOT_EC_INSUFFICIENT_MEMORY;
			goto err_out;
		}		
		if (0 == (sub->thing = (THING**)memory_alloc(sizeof(THING*) * sub->length))) {
			ec = IWOT_EC_INSUFFICIENT_MEMORY;
			goto err_out;
		}	
		singletonThingSub = sub;	
	}
	*result = sub;

	return ec;
err_out:
	if (0 != sub) {
		if (0 != sub->topic) {
			memory_free(sub->topic);
		}
		if (0 != sub->thing) {
			memory_free(sub->thing);
		}
		memory_free(sub);
	}
	return ec;
}
*/

void _free_thing_config(THINGCONFIG **config)
{
	if (*config != 0) {
		iwot_util_free_string(&(*config)->accessKey);
		iwot_util_free_string(&(*config)->secretKey);
		iwot_util_free_string(&(*config)->host);
		iwot_util_free_string(&(*config)->id);
		iwot_util_free_string(&(*config)->classID);
		iwot_util_free_string(&(*config)->modelJSON);
			
		memory_free(*config);
		*config = 0;			
	}	
}

IWOTERRORCODE _create_thing_config(IWOTCONFIG *cfg, THINGCONFIG **result)
{
	IWOTERRORCODE ec = IWOT_EC_SUCCESS;
	int size = sizeof(THINGCONFIG);
	THINGCONFIG *config = 0;
	
	if (0 == cfg->accessKey || 0 == cfg->modelJSON) { 
		ec = IWOT_EC_INVALID_DATA;
		goto err_out;
	}
	
	if (0 == (config = memory_alloc(size))) { 
		ec = IWOT_EC_INSUFFICIENT_MEMORY;
		goto err_out;
	}	

	memset(config, 0, size);
	
	if (IWOT_EC_SUCCESS != (ec = json_parse_model(cfg->modelJSON, &config->model))) {
		goto err_out;
	}		
	
	if (0 == config->model->id || 0 == config->model->classID) {
		ec = IWOT_EC_INVALID_DATA;
		goto err_out;		
	}	
					
	if (0 != cfg->accessKey && IWOT_EC_SUCCESS != (ec = iwot_util_copy_string(cfg->accessKey, &config->accessKey))) {
		goto err_out;
	}					
	if (0 != cfg->secretKey && IWOT_EC_SUCCESS != (ec = iwot_util_copy_string(cfg->secretKey, &config->secretKey))) {
		goto err_out;
	}					
	if (0 != cfg->host && IWOT_EC_SUCCESS != (ec = iwot_util_copy_string(cfg->host, &config->host))) {
		goto err_out;
	}				
	if (IWOT_EC_SUCCESS != (ec = iwot_util_copy_string(config->model->id, &config->id))) {
		goto err_out;
	}					
	if (IWOT_EC_SUCCESS != (ec = iwot_util_copy_string(config->model->classID, &config->classID))) {
		goto err_out;
	}					
	if (0 != cfg->modelJSON && IWOT_EC_SUCCESS != (ec = iwot_util_copy_string(cfg->modelJSON, &config->modelJSON))) {
		goto err_out;
	}										
	config->properties = cfg->properties;  
	config->keepAlive = cfg->keepAlive * 2 / 3;  

	*result = config;
	return ec;
err_out:	
	if (0 != config) {
		_free_thing_config(&config);	
	}

	return ec;  
}

IWOTERRORCODE _get_value_def(IWOTMODEL *model, char *obj, char *group, char *item, IWOTVALUEDEF **result)
{
    IWOTVARDEF **var = 0;
    IWOTVALUEDEF **value = 0;
    int varCount = 0;
    int i, j;

	if (0 == strcmp(obj, "properties")) {
		var = model->properties;
		varCount = model->propertiesCount;
	} else if (0 == strcmp(obj, "actions")) {
		var = model->actions;
		varCount = model->actionsCount;
	} else if (0 == strcmp(obj, "events")) {
		var = model->events;
		varCount = model->eventsCount;
	} else {
		return IWOT_EC_NULL_DATA;
	}

	for (i = 0; i < varCount; i++, var++) {
		if(0 != strcmp((*var)->id, group)) {
			continue;
		}
		value = (*var)->values;
		for (j = 0; j < (*var)->valuesCount; j++, value++) {
			if (0 != strcmp((*value)->id, item)) {
				continue;
			}
			*result = *value;
			return IWOT_EC_SUCCESS;
		}
	}

	return IWOT_EC_NULL_DATA;
}

void _correct_var_type(IWOTVARITEM *item, IWOTVALUEDEF *def)
{
	char *s;
	if (item->type != IWOT_STRING) {
		return;
	}
		 
	if (def->type != 0) {
		s = item->value.string;
		if (0 == strcmp(def->type, "integer")) {
			item->type = IWOT_INTEGER;
			item->value.integer = atoi(item->value.string);
			iwot_util_free_string(&s);			
		} else if (0 == strcmp(def->type, "float")) {
			item->type = IWOT_FLOAT;
			sscanf(item->value.string, "%lf", &item->value.floating);
			iwot_util_free_string(&s);
		} else if (0 == strcmp(def->type, "boolean")) {
			item->type = IWOT_BOOLEAN;
			if (0 == strcmp(item->value.string, "true")) {
				item->value.integer = 1;	
			} else {
				item->value.integer = 0;
			}
			iwot_util_free_string(&s);
		}	
	}
}

IWOTERRORCODE _change_status(IWOTVAROBJECT *var, int code) {
	IWOTERRORCODE ec = IWOT_EC_SUCCESS;
	char *status[] = {"completed", "failed", "executing"};
	IWOTVARGROUP **groups = var->groups;	
	int i;

	if (code < 0 || code > 2) {
		return IWOT_EC_INVALID_DATA;
	}

	for (i = 0; i < var->groupCount; i++, groups++) {	
		if ((*groups)->status != 0)	{
			iwot_util_free_string(&((*groups)->status));
		}
		if (0 != status[code] && IWOT_EC_SUCCESS != (ec = iwot_util_copy_string(status[code], &((*groups)->status)))) {
			return ec;
		}
	}	
	return ec;
}

void _mqtt_message_callback(char *topic, char *payload, IWOTVAROBJECT *obj, int qos)
{
	THINGSUB *thingSub = 0;
	int i, j, k;
	IWOTVARGROUP **groups;
	IWOTVARITEM **items;	
	IWOTMODEL *model;
	IWOTVALUEDEF *value;
	int ec = 0;	
	int type = 0;	

	if(IWOT_EC_SUCCESS != _thingsub_get(&thingSub)) {
		return;
	}

	for (i = 0; i < thingSub->used; i++) {
		if (0 != thingSub->topic[i] && 0 == strcmp(thingSub->topic[i], topic)) {
			if (0 == strcmp(obj->identifier, "properties")) {
				type = 1;	
			} else if (0 == strcmp(obj->identifier, "actions")) {
				type = 2;	
			} else if (0 == strcmp(obj->identifier, "buildins")) {
				type = 3;	
			}			
			if (type > 0) {
				groups = obj->groups;
#if IWOT_OPT_ENABLE_MQTT_MODEL					
				model = thingSub->thing[i]->iwotConfig->model;
				for (j = 0; j < obj->groupCount; j++, groups++) {
					items = (*groups)->items;
					for (k = 0; k < (*groups)->itemCount; k++, items++) {
						if (IWOT_EC_SUCCESS == _get_value_def(model, obj->identifier, (*groups)->identifier, (*items)->key, &value)) {
							_correct_var_type(*items, value);	
						}
					}		
				}
#endif				
				_change_status(obj, 2);
				if (type > 1) {
					iwot_thing_publish_properties(thingSub->thing[i], obj, qos);					
				}				
				if (type == 1 && 0 != thingSub->thing[i]->propertyHandler) {
					ec = thingSub->thing[i]->propertyHandler(obj) == 0 ? 0 : 1;
				} else if (type == 2 && 0 != thingSub->thing[i]->actionHandler) {
					ec = thingSub->thing[i]->actionHandler(obj) == 0 ? 0 : 1;
				} else if (type == 3 && 0 != thingSub->thing[i]->systemHandler) {
					ec = thingSub->thing[i]->systemHandler(obj) == 0 ? 0 : 1;
				} else {
					ec = 0;
				}				
				_change_status(obj, ec);
				iwot_thing_publish_properties(thingSub->thing[i], obj, qos);
			}			
		}
	}	
}

IWOTERRORCODE _serialize_var_object(IWOTVAROBJECT *object, char **result, int qos, char *thingID)
{
	IWOTERRORCODE ec = IWOT_EC_SUCCESS;
	char *payload = 0;
	int i, j;
	char *ending = 0;

	IWOTVARGROUP **group = object->groups;
	IWOTVARITEM **item;

	if (0 == (payload = (char*)memory_alloc(2048))) {
		return IWOT_EC_INSUFFICIENT_MEMORY;		
	}
	memset(payload, 0, 2048);
	ending = payload;

	if (object->groupCount > 0) {
		sprintf(ending, "{\"%s\":{", object->identifier);	
		for (i = 0; i < object->groupCount; i++, group++) {
			if ((*group)->itemCount > 0) {
				ending = payload + strlen(payload);	
			    sprintf(ending, "\"%s\":{\"values\":{", (*group)->identifier);	    
			    item = (*group)->items;
			    for (j = 0; j < (*group)->itemCount; j++, item++) {
					ending = payload + strlen(payload);	
					if ((*item)->type == IWOT_INTEGER) {
						sprintf(ending, "\"%s\":%d,", (*item)->key, (*item)->value.integer);	    	    						
					} else if ((*item)->type == IWOT_STRING) {
						sprintf(ending, "\"%s\":\"%s\",", (*item)->key, (*item)->value.string);	    	    						
					} else if ((*item)->type == IWOT_FLOAT) {
						sprintf(ending, "\"%s\":%f,", (*item)->key, (*item)->value.floating);	    	    						
					} else if ((*item)->type == IWOT_BOOLEAN) {
						if ((*item)->value.integer == 0) {
							sprintf(ending, "\"%s\":false,", (*item)->key);	    	    						
						} else {
							sprintf(ending, "\"%s\":true,", (*item)->key);	    	    						
						}				
					}
			    }
				ending = payload + (strlen(payload) - 1);	
			    sprintf(ending, "},");	  
			    if (0 != (*group)->timestamp) {
					ending = payload + (strlen(payload));	
			    	sprintf(ending, "\"timestamp\":\"%s\",", (*group)->timestamp);	  			    	
			    }
			    if (0 != (*group)->status) {
					ending = payload + (strlen(payload));	
			    	sprintf(ending, "\"status\":\"%s\",", (*group)->status);	  			    	
			    }
			    if (0 != (*group)->id) {
					ending = payload + (strlen(payload));	
			    	sprintf(ending, "\"id\":\"%s\",", (*group)->id);	  			    	
			    }			    		
				ending = payload + (strlen(payload) - 1);	
			    sprintf(ending, "},");	  			    	    
			}		  	   
		}	
		ending = payload + (strlen(payload) - 1);
		sprintf(ending, "},\"thingID\":\"%s\",\"QoS\":%d}", thingID, qos);
	}

	*result = payload;

	return IWOT_EC_SUCCESS;
}

IWOTERRORCODE _publish_topic(char *token, char *id, char *classID, char *type, char *payload, int qos, THING *thing)
{
	IWOTERRORCODE ec = IWOT_EC_SUCCESS;
	char *topic = 0;
	int len;	

	if (id != 0) {
		len = sizeof(char) * (strlen(token) + strlen(id) + strlen(type) + 3);		
	} else if (classID != 0) {
		len = sizeof(char) * (strlen(token) + strlen(classID) + strlen(type) + 3);
	} else {
		ec = IWOT_EC_INVALID_DATA;
		goto err_out;
	}
	
	if (0 == (topic = (char*)memory_alloc(len))) {
		ec = IWOT_EC_INSUFFICIENT_MEMORY;
		goto err_out;		
	}
	memset(topic, 0, len);

	if (id != 0) {
		sprintf(topic, "%s/%s/%s", token, id, type);
	} else {
		sprintf(topic, "%s/%s/%s", token, classID, type);
	}
	
    ec = mqtt_publish_topic(thing->broker, topic, qos, payload);	    

err_out:
	if (0 != topic) {
		memory_free(topic);   	
	}
    
	return ec;
}

IWOTERRORCODE _subscribe_topic(char *token, char *id, THING *thing) 
{
	IWOTERRORCODE ec = IWOT_EC_SUCCESS;
	THINGSUB *thingSub = 0;
	int size = sizeof(char) * (strlen(token) + strlen(id) + 12);	
	char *topic = 0;

	if (IWOT_EC_SUCCESS != (ec = _thingsub_get(&thingSub))) {
		goto err_out;
	}

	if (0 == (topic = (char*)memory_alloc(size))) {
		ec = IWOT_EC_INSUFFICIENT_MEMORY;
		goto err_out;
	}

    memset(topic, 0, size);
	sprintf(topic, "%s/%s/set/delta", token, id);
    if (IWOT_EC_SUCCESS != (ec = mqtt_subscribe_topic(thing->broker, topic, 2, _mqtt_message_callback))) {
    	return ec;
    }

    thingSub->topic[thingSub->used] = topic;
    thingSub->thing[thingSub->used] = thing;
    (thingSub->used)++; 

    return ec;
err_out:
	if (0 != topic) {
		memory_free(topic);
	}
	return ec;       	
}

IWOTERRORCODE iwot_thing_init(IWOTCONFIG *config, THING **result)
{
	IWOTERRORCODE ec = IWOT_EC_SUCCESS;
	THING *thing;
	char **connOpts;
	/*char *id = config->model != 0 ? config->model->id : config->id;*/
	int retry = 0;
	IWOTMODEL *model = 0;

	if (0 == (thing = (THING*)memory_alloc(sizeof(THING)))) {
		ec = IWOT_EC_INSUFFICIENT_MEMORY;
		goto err_out;
	}
	memset(thing, 0, sizeof(THING));

	if (0 == (thing->brokerConfig = (MQTTCONFIG*)memory_alloc(sizeof(MQTTCONFIG)))) {		
		ec = IWOT_EC_INSUFFICIENT_MEMORY;
		goto err_out;
	}	
	memset(thing->brokerConfig, 0, sizeof(MQTTCONFIG));
	
	if(IWOT_EC_SUCCESS != (ec = _create_thing_config(config, &thing->iwotConfig))) {
		goto err_out;
	}	
						
	retry = IWOT_OPT_MAX_NETWORK_RETRY;
#if IWOT_OPT_FROM_CLASS_BUILDER
	while (IWOT_EC_SUCCESS != (ec = download_certificate(config->accessKey, config->secretKey, config->host, &thing->brokerConfig->host, &thing->brokerConfig->port, &thing->brokerConfig->protocol, &thing->brokerConfig->token, &thing->brokerConfig->cert, &thing->brokerConfig->key))) { 	
#else
	while (IWOT_EC_SUCCESS != (ec = download_connect_package(config->accessKey, config->secretKey, config->host, thing->iwotConfig->id, &thing->brokerConfig->host, &thing->brokerConfig->port, &thing->brokerConfig->protocol, &thing->brokerConfig->token, &thing->brokerConfig->cert, &thing->brokerConfig->key, &model))) {	
#endif		
		if (0 > --retry) {
			goto err_out;
		}		
		debug_log("Download certifictae failed. Retry 3 seconds later. (%d)", retry);
		doze_off(3000);					
	}
	debug_log("Download certifictae successfully.");	
	
	if(0 != model) {
		if (0 != iwot_util_compare_model(thing->iwotConfig->model, model)) {
			ec = IWOT_EC_INCONSISTENT_MODEL;
		}
	}
	
#if IWOT_OPT_FROM_CLASS_BUILDER
#else
		iwot_util_free_model(&thing->iwotConfig->model);
		thing->iwotConfig->model = model;				
#endif

	if (0 == (thing->brokerConfig->clientID = (char*)memory_alloc(sizeof(char) * (strlen(thing->brokerConfig->token) + strlen(thing->iwotConfig->id) + 7)))) {		
		ec = IWOT_EC_INSUFFICIENT_MEMORY;
		goto err_out;
	}	    	
	sprintf(thing->brokerConfig->clientID, "csdk_%s_%s", thing->brokerConfig->token, thing->iwotConfig->id);    	    	
	
	thing->brokerConfig->accessKey = config->accessKey;
	thing->brokerConfig->secretKey = config->secretKey; 

    *result = thing;
    return ec;

err_out:	
	if (0 != thing) {
		iwot_thing_uninit(&thing);
	}			
    return ec;
}

IWOTERRORCODE iwot_thing_connect(THING* thing, IWOTHANDLER actionHandler, IWOTHANDLER propertyHandler, IWOTHANDLER systemHandler)
{
	IWOTERRORCODE ec = IWOT_EC_SUCCESS;
	char *id = thing->iwotConfig->model != 0 ? thing->iwotConfig->model->id : thing->iwotConfig->id;
	char *classID = thing->iwotConfig->model != 0 ? thing->iwotConfig->model->classID : thing->iwotConfig->classID;
	char *payload = 0;
	int retry = 0;
	int payloadLen = 128;
	
#if IWOT_OPT_ENABLE_MQTT_MODEL		
	/*if (0 == thing->iwotConfig->model && 0 == thing->iwotConfig->modelJSON) {
		debug_log("Try to download model first.");	
		download_model (thing->iwotConfig->accessKey, thing->iwotConfig->secretKey, thing->iwotConfig->host, id, &thing->iwotConfig->model);
		if (0 != thing->iwotConfig->model) {
			debug_log("Download model successfully.");	
		}
	}*/
#else
	/*if (0 == thing->iwotConfig->model) {
		iwot_util_create_model(id, classID, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, &thing->iwotConfig->model);
	}
	debug_log("Empty model mode!!!");	*/
#endif

	if (0 == thing->iwotConfig->model && 0 != thing->iwotConfig->modelJSON) {
		payloadLen += strlen(thing->iwotConfig->modelJSON);
	}

	if (0 == (payload = (char*)memory_alloc(payloadLen))) {
		ec = IWOT_EC_INSUFFICIENT_MEMORY;
		return ec;
	}
	memset(payload, 0, payloadLen);

	debug_log("Try to connect MQTT server.");	
	retry = IWOT_OPT_MAX_NETWORK_RETRY;
	thing->brokerConfig->id = id;
	thing->brokerConfig->keepAlive = thing->iwotConfig->keepAlive;
	while (IWOT_EC_SUCCESS != (ec = mqtt_create_client(thing->brokerConfig, &thing->broker))) {		
		if (0 > --retry) {
			goto err_out;
		}				
		debug_log("Fail to connect MQTT server. Retry 3 seconds later. (%d)", retry);
		doze_off(3000);					
	}
	debug_log("Connect to MQTT server successfully.");		

	thing->actionHandler = actionHandler;
	thing->propertyHandler = propertyHandler;	
	thing->systemHandler = systemHandler;	

	if (actionHandler != 0 || propertyHandler != 0 || systemHandler != 0) {
		if (IWOT_EC_SUCCESS != _subscribe_topic(thing->brokerConfig->token, classID, thing)) {
			debug_log("subscribe classID topic failed.");
		}

		if (IWOT_EC_SUCCESS != _subscribe_topic(thing->brokerConfig->token, id, thing)) {
			debug_log("subscribe id topic failed.");
		}	
	}

	if (0 == thing->iwotConfig->model && 0 != thing->iwotConfig->modelJSON) {		
		sprintf(payload, "{\"model\":{\"id\":\"%s\",%s}", id, &thing->iwotConfig->modelJSON[1]);
	} else {
		sprintf(payload, "{\"model\":{\"id\":\"%s\",\"classID\":\"%s\"}}", id, classID);
	}

	if (IWOT_EC_SUCCESS != _publish_topic(thing->brokerConfig->token, id, 0, "update", payload, 0, thing)) {
		debug_log("publish model topic failed.");
	}				
	
#if IWOT_OPT_ENABLE_MQTT_MODEL		
	retry = IWOT_OPT_MAX_NETWORK_RETRY;
	while (thing->iwotConfig->model == 0 && IWOT_EC_SUCCESS != (ec = download_model (thing->iwotConfig->accessKey, thing->iwotConfig->secretKey, thing->iwotConfig->host, id, &thing->iwotConfig->model))) {
		if (0 > --retry) {
			goto err_out;
		}		
		debug_log("Download model failed. Retry 3 seconds later. (%d)", retry);
		doze_off(3000);
	}
	debug_log("Download model successfully.");
#endif	

    if (thing->iwotConfig->properties != 0) {    	
		if (IWOT_EC_SUCCESS != iwot_thing_publish_properties(thing, thing->iwotConfig->properties, 0)) {
			debug_log("publish properties failed.");
		}		    	
    }

	if (IWOT_EC_SUCCESS != _publish_topic(thing->brokerConfig->token, id, 0, "life", "{\"cycle\":\"birth\"}", 0, thing)) {
		debug_log("publish life topic failed.");
	}	    

#if IWOT_OPT_ENABLE_MQTT_THREAD
	mqtt_poll_message_thread(thing->broker);
#endif  	
       
err_out:
	if (0 != payload) {
		memory_free(payload);	
	}	
	if (IWOT_EC_SUCCESS != ec) {
		if (0 != thing->broker) {
			mqtt_delete_client(&thing->broker);	
		}		
	}
  	return ec;
}

IWOTERRORCODE iwot_thing_yield(THING* thing)
{
	return mqtt_poll_message(thing->broker);	
}

IWOTERRORCODE iwot_thing_publish_properties(THING* thing, IWOTVAROBJECT *object, int qos)
{
	char* payload = 0;
	IWOTERRORCODE ec = IWOT_EC_SUCCESS;

	if (IWOT_EC_SUCCESS != (ec = iwot_util_verify_object(thing->iwotConfig->model, object))) {
		goto err_out;
	}

	if (IWOT_EC_SUCCESS != (ec = _serialize_var_object(object, &payload, qos, thing->iwotConfig->model->id))) {
		goto err_out;
	}

	ec = _publish_topic(thing->brokerConfig->token, thing->iwotConfig->model->id, 0, "update", payload, qos, thing);   

err_out:
	if (0 != payload) {
		iwot_util_free_string(&payload);	
	}	

	return ec;	
}

IWOTERRORCODE iwot_thing_emit_events(THING* thing, IWOTVAROBJECT *object, int qos, int broadcast)
{
	IWOTERRORCODE ec = IWOT_EC_SUCCESS;
	char* payload = 0;
	char* id = broadcast == 0 ? thing->iwotConfig->model->id : 0;
	char* classID = broadcast == 1 ? thing->iwotConfig->model->classID : 0;

	if (IWOT_EC_SUCCESS != (ec = iwot_util_verify_object(thing->iwotConfig->model, object))) {
		goto err_out;
	}	

	if (IWOT_EC_SUCCESS != (ec = _serialize_var_object(object, &payload, qos, thing->iwotConfig->model->id))) {
		goto err_out;
	}	

	ec = _publish_topic(thing->brokerConfig->token, id, classID, "update", payload, qos, thing);   

err_out:
	if (0 != payload) {
		iwot_util_free_string(&payload);	
	}	

	return ec;	
}

IWOTERRORCODE iwot_thing_download_firmware(THING* thing, IWOTVAROBJECT *object, const char *dst)
{
	IWOTERRORCODE ec = IWOT_EC_INVALID_DATA;
	IWOTVARGROUP **groups = object->groups;
	IWOTVARITEM **items;
	int i = 0, j = 0, k = 0, c = 0;
	char *s = 0;	
  
	for (i = 0; i < object->groupCount; i++, groups++) {  
		if(0 == strcmp((*groups)->identifier, "upgradeFirmware")) {
			items = (*groups)->items;  
			for (j = 0; j < (*groups)->itemCount; j++, items++) {
				if (0 == strcmp((*items)->key, "url")) {
					s = (*items)->value.string; 

					do {
						if ('/' == s[k] && 3 == ++c) {							
							break;
						}			
						k++;			
					} while ('\0' != s[k]);

					return download_firmware (thing->iwotConfig->accessKey, thing->iwotConfig->secretKey, thing->iwotConfig->host, &s[k], dst);
				}
			}    
		}          
	}
	
	return ec;
}

void iwot_thing_disconnect(THING *thing)
{
	if (0 != thing) {
		if (0 != thing->brokerConfig && 0 != thing->iwotConfig && 0 != thing->iwotConfig->model) {
			_publish_topic(thing->brokerConfig->token, thing->iwotConfig->model->id, 0, "life", "{\"cycle\":\"death\"}", 0, thing);	
		}		
		_thingsub_remove_thing(thing);
			
		if (0 != thing->broker) {
			mqtt_delete_client(&thing->broker);
		}
	}	
}

void iwot_thing_uninit(THING **thing)
{
	THING *target = *thing;
	if (0 != target) {
		
		iwot_thing_disconnect(target);
		
		if (0 != target->iwotConfig) {
			_free_thing_config(&target->iwotConfig);
		}
		if (0 != target->brokerConfig) {
			if (0 != target->brokerConfig->host) {
				iwot_util_free_string(&target->brokerConfig->host);
			}
			if (0 != target->brokerConfig->protocol) {
				iwot_util_free_string(&target->brokerConfig->protocol);
			}
			if (0 != target->brokerConfig->token) {
				iwot_util_free_string(&target->brokerConfig->token);
			}	
			if (0 != target->brokerConfig->clientID) {
				iwot_util_free_string(&target->brokerConfig->clientID);
			}															
			memory_free(target->brokerConfig);
			target->brokerConfig = 0;
		}		
		memory_free(target);
		*thing = 0;
	}	
}
