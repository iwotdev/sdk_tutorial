#ifndef _IWOT_HTTP_HEADER_
#define _IWOT_HTTP_HEADER_

#include "iwot_util.h"

#ifdef __cplusplus 
extern "C" { 
#endif

typedef struct _httpConfig {
	char *host;
	int  port;
	char *path;
	char *protocol;
	char *accessKey;
	char *secretKey;
} HTTPCONFIG;

IWOTERRORCODE http_request(HTTPCONFIG *config, char **result, unsigned int maxLen, unsigned int *resultLen);

#ifdef __cplusplus 
} 
#endif 

#endif