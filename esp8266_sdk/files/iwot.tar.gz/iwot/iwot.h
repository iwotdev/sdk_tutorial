#ifndef _IWOT_HEADER_
#define _IWOT_HEADER_

#ifdef __cplusplus
extern "C" { 
#endif

#include "iwot_util.h"  
    
#ifndef _IWOT_MQTT_HEADER_    
typedef struct _mqttConfig MQTTCONFIG;
typedef struct _mqttClient MQTTCLIENT;
#endif

typedef int (*IWOTHANDLER)(IWOTVAROBJECT *var);

typedef struct _thingConfig {
    char *accessKey;
    char *secretKey;
    char *host;
    char *id;
    char *classID;    
    IWOTMODEL *model;
    IWOTVAROBJECT *properties;
    unsigned int keepAlive;
    char *modelJSON;
} THINGCONFIG;

typedef struct _thing {
	THINGCONFIG *iwotConfig;
	MQTTCONFIG *brokerConfig;
	MQTTCLIENT *broker;
	IWOTHANDLER actionHandler;
	IWOTHANDLER propertyHandler;
	IWOTHANDLER systemHandler;
} THING; 

IWOTERRORCODE iwot_thing_init(IWOTCONFIG *config, THING **result);
IWOTERRORCODE iwot_thing_connect(THING* thing, IWOTHANDLER actionHandler, IWOTHANDLER propertyHandler, IWOTHANDLER systemHandler);
IWOTERRORCODE iwot_thing_yield(THING* thing);
IWOTERRORCODE iwot_thing_publish_properties(THING* thing, IWOTVAROBJECT *object, int qos);
IWOTERRORCODE iwot_thing_emit_events(THING* thing, IWOTVAROBJECT *object, int qos, int broadcast);
IWOTERRORCODE iwot_thing_download_firmware(THING* thing, IWOTVAROBJECT *object, const char *dst);
void iwot_thing_disconnect(THING *thing);
void iwot_thing_uninit(THING **thing);

#ifdef __cplusplus
}
#endif

#endif