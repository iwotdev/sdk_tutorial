iWoT embedded C SDK

version:
0.0.2

release date:
2016/11/1

installation:
1. arduino
/* + /platform/arduino/* + 3rdParty/comm/* + 3rdParty/arduino/*

2. freertos
/* + /platform/freertos/* + 3rdParty/comm/* + 3rdParty/freertos/*

3. linux
run ./install/linux.sh
