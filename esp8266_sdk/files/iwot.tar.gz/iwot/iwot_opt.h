#ifndef _IWOT_OPT_HEADER_
#define _IWOT_OPT_HEADER_

#ifdef __cplusplus 
extern "C" { 
#endif

#define IWOT_OPT_ENABLE_DEBUG		1
#define IWOT_OPT_ENABLE_FPU			1
#define IWOT_OPT_ENABLE_MQTT_QOS	1			
#define IWOT_OPT_MAX_NETWORK_RETRY	10
#define IWOT_OPT_TCP_TIMEOUT		3000
#define IWOT_OPT_ENABLE_SSL			0 //1	
#define IWOT_OPT_ENABLE_MQTT_THREAD	1	
#define IWOT_OPT_ENABLE_MQTT_MODEL	1
#define IWOT_OPT_FROM_CLASS_BUILDER 0	

#define IWOT_OPT_MAX_MODEL_SIZE     2048			

#ifdef __cplusplus 
} 
#endif 

#endif 