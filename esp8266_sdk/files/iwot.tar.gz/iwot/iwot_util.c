#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "iwot_util.h"
#include "system_wrapper.h"

IWOTERRORCODE iwot_util_copy_string(const char *src, char **dst)
{
	IWOTERRORCODE ec = IWOT_EC_SUCCESS;
	int len;
	char *result;

	if (0 == src) { 
		ec = IWOT_EC_INVALID_DATA;
		goto err_out;
	}

	len = strlen(src) + 1;
	if (0 == (result = memory_alloc(sizeof(char) * len))) {
		ec = IWOT_EC_INSUFFICIENT_MEMORY;
		goto err_out;
	}

	strcpy(result, src);
	*dst = result;

err_out:
	return ec;
}

IWOTERRORCODE iwot_util_copy_string_partial(const char *src, char **dst, int from, int length)
{
	IWOTERRORCODE ec = IWOT_EC_SUCCESS;
	int len;
	char *result;
	const char *start;

	if (0 == src) { 
		ec = IWOT_EC_INVALID_DATA;
		goto err_out;
	}

	len = length + 1;
	if (0 == (result = memory_alloc(sizeof(char) * len))) {
		ec = IWOT_EC_INSUFFICIENT_MEMORY;
		goto err_out;
	}

	start = src + from;
	//strncpy(result, start, length);
	memcpy(result, start, length);
	result[length] = '\0';
	*dst = result;

err_out:
	return ec;
}

IWOTERRORCODE iwot_util_concat_string(char *src1, size_t len1, char *src2, size_t len2, char **dst)
{
	IWOTERRORCODE ec = IWOT_EC_SUCCESS;
	size_t len;
	char *result;

	if (0 == src1 || 0 == src2) { 
		ec = IWOT_EC_INVALID_DATA;
		goto err_out;
	}

	len = len1 + len2 + 1;
	if (0 == (result = memory_alloc(sizeof(char) * len))) {
		ec = IWOT_EC_INSUFFICIENT_MEMORY;
		goto err_out;
	}

	//sprintf(result, "%s%s\0", src1, src2);
	memcpy(result, src1, len1);
	memcpy(result + len1, src2, len2);
	result[len1 + len2] = '\0';

	if (src1 == *dst) {
		memory_free(src1);
	}
	if (src2 == *dst) {
		memory_free(src2);
	}	

	*dst = result;

err_out:
	return ec;
}

IWOTERRORCODE iwot_util_concat_memory(char *src1, size_t len1, char *src2, size_t len2, char **dst)
{
	IWOTERRORCODE ec = IWOT_EC_SUCCESS;
	size_t len;
	char *result;

	if (0 == src1 || 0 == src2) { 
		ec = IWOT_EC_INVALID_DATA;
		goto err_out;
	}

	len = len1 + len2;
	if (0 == (result = memory_alloc(sizeof(char) * len))) {
		ec = IWOT_EC_INSUFFICIENT_MEMORY;
		goto err_out;
	}

	//sprintf(result, "%s%s\0", src1, src2);
	if (len1 > 0) {
		memcpy(result, src1, len1);	
	}
	if (len2 > 0) {
		memcpy(result + len1, src2, len2);	
	}
	
	if (src1 == *dst) {
		memory_free(src1);
	}
	if (src2 == *dst) {
		memory_free(src2);
	}	

	*dst = result;

err_out:
	return ec;
}

IWOTERRORCODE iwot_util_copy_string_array(char **src, int size, char ***dst)
{
	IWOTERRORCODE ec = IWOT_EC_SUCCESS;
	char **tmp;
	char **result = 0;
	int i;

	if (0 == src || 0 >= size) { 
		ec = IWOT_EC_INVALID_DATA;
		goto err_out;
	}

	if (0 == (result = memory_alloc(sizeof(char*) * size))) {
		ec = IWOT_EC_INSUFFICIENT_MEMORY;
		goto err_out;
	}	

	tmp = result;
	for (i = 0; i < size; i++, tmp++) {		
		if (0 != src[i] && IWOT_EC_SUCCESS != (ec = iwot_util_copy_string(src[i], tmp))) {
			goto err_out;
		}
	}	

	*dst = result;
	return ec;

err_out:
	if (0 != result) {
		iwot_util_free_string_array(&result, size);
	}
	
	return ec;	
}

IWOTERRORCODE iwot_util_create_string_array(int size, char ***dst)
{
	IWOTERRORCODE ec = IWOT_EC_SUCCESS;
	char **tmp = 0;
	int l;
	
	if (0 >= size) { 
		ec = IWOT_EC_INVALID_DATA;
		goto err_out;
	}	

	l = sizeof(char*) * size;
	if (0 == (tmp = memory_alloc(l))) {
		ec = IWOT_EC_INSUFFICIENT_MEMORY;
		goto err_out;
	}		

	memset(tmp, 0, l);
	*dst = tmp;

err_out:
	return ec;
}

IWOTERRORCODE iwot_util_create_var_object(const char *identifier, int groupCount, IWOTVAROBJECT **result) 
{
	IWOTERRORCODE ec = IWOT_EC_SUCCESS;
	int size1 = sizeof(IWOTVAROBJECT);
	int size2;
	IWOTVAROBJECT *object = 0;
	if (0 == (object = memory_alloc(size1))) {
		ec = IWOT_EC_INSUFFICIENT_MEMORY;
		goto err_out;
	}			

	memset(object, 0, size1);

	if(0 != identifier && IWOT_EC_SUCCESS != (ec = iwot_util_copy_string(identifier, &object->identifier))) {
		goto err_out;
	}
	object->groupCount = groupCount;
	if (groupCount == 0) {
		object->groups = 0;
	} else {
		size2 = sizeof(IWOTVARGROUP*) * groupCount;		
		if (0 == (object->groups = memory_alloc(size2))) {
			ec = IWOT_EC_INSUFFICIENT_MEMORY;
			goto err_out;
		}					
		memset(object->groups, 0, size2);
	}	

	*result = object;

err_out:
	if (IWOT_EC_SUCCESS != ec) {
		if (0 != object) {
			iwot_util_free_var_object(&object);
		}
	}

	return ec;	
}

IWOTERRORCODE iwot_util_create_var_group(const char *identifier, int itemCount, const char* timestamp, const char* status, const char* id, IWOTVARGROUP **result) 
{
	IWOTERRORCODE ec = IWOT_EC_SUCCESS;
	int size1 = sizeof(IWOTVARGROUP);
	int size2;
	IWOTVARGROUP *group = 0;
	if (0 == (group = memory_alloc(size1))) {
		ec = IWOT_EC_INSUFFICIENT_MEMORY;
		goto err_out;
	}				

	memset(group, 0, size1);

	if(0 != identifier && IWOT_EC_SUCCESS != (ec = iwot_util_copy_string(identifier, &group->identifier))) {
		goto err_out;
	}
	if(0 != timestamp && IWOT_EC_SUCCESS != (ec = iwot_util_copy_string(timestamp, &group->timestamp))) {
		goto err_out;
	}
	if(0 != status && IWOT_EC_SUCCESS != (ec = iwot_util_copy_string(status, &group->status))) {
		goto err_out;
	}
	if(0 != id && IWOT_EC_SUCCESS != (ec = iwot_util_copy_string(id, &group->id))) {
		goto err_out;
	}			
		    
	group->itemCount = itemCount;
	if (itemCount == 0) {
		group->items = 0;
	} else {
		size2 = sizeof(IWOTVARITEM*) * itemCount;		
		if (0 == (group->items = memory_alloc(size2))) {
			ec = IWOT_EC_INSUFFICIENT_MEMORY;
			goto err_out;
		}						
		memset(group->items, 0, size2);
	}	

	*result = group;

err_out:
	if (IWOT_EC_SUCCESS != ec) {
		if (0 != group) {
			iwot_util_free_var_group(&group);
		}
	}

	return ec;	
}

IWOTERRORCODE iwot_util_create_var_item(const char *key, IWOTVARITEM **result)
{
	IWOTERRORCODE ec = IWOT_EC_SUCCESS;
	int size = sizeof(IWOTVARITEM);
	IWOTVARITEM *item = 0;
	if (0 == (item = memory_alloc(size))) {
		ec = IWOT_EC_INSUFFICIENT_MEMORY;
		goto err_out;
	}					

	memset(item, 0, size);

	if(0 != key && IWOT_EC_SUCCESS != (ec = iwot_util_copy_string(key, &item->key))) {
		goto err_out;
	}				

	*result = item;

err_out:
	if (IWOT_EC_SUCCESS != ec) {
		if (0 != item) {
			iwot_util_free_var_item(&item);
		}
	}
	return ec;
}

IWOTERRORCODE iwot_util_create_var_item_string(const char *key, const char *value, IWOTVARITEM **result)
{
	IWOTERRORCODE ec = IWOT_EC_SUCCESS;
	IWOTVARITEM* item = 0;

	if (IWOT_EC_SUCCESS != (ec = iwot_util_create_var_item(key, &item))) {
		return ec;
	}

	if (0 != value && IWOT_EC_SUCCESS != (ec = iwot_util_copy_string(value, &item->value.string))) {
		iwot_util_free_var_item(&item);
		return ec;
	}
		
	item->type = IWOT_STRING;
	*result = item;

	return ec;
}

IWOTERRORCODE iwot_util_create_var_item_integer(const char *key, const int value, IWOTVARITEM **result)
{
	IWOTERRORCODE ec = IWOT_EC_SUCCESS;
	IWOTVARITEM* item = 0;

	if (IWOT_EC_SUCCESS != (ec = iwot_util_create_var_item(key, &item))) {
		return ec;
	}

	item->value.integer = value;	
	item->type = IWOT_INTEGER;
	*result = item;

	return ec;	
}

#if IWOT_OPT_ENABLE_FPU 
IWOTERRORCODE iwot_util_create_var_item_float(const char *key, const double value, IWOTVARITEM **result)
{
	IWOTERRORCODE ec = IWOT_EC_SUCCESS;
	IWOTVARITEM* item = 0;

	if (IWOT_EC_SUCCESS != (ec = iwot_util_create_var_item(key, &item))) {
		return ec;
	}

	item->value.floating = value;
	item->type = IWOT_FLOAT;
	*result = item;

	return ec;			
}
#endif

IWOTERRORCODE iwot_util_create_var_item_boolean(const char *key, const int value, IWOTVARITEM **result)
{
	IWOTERRORCODE ec = IWOT_EC_SUCCESS;
	IWOTVARITEM* item = 0;

	if (IWOT_EC_SUCCESS != (ec = iwot_util_create_var_item(key, &item))) {
		return ec;
	}

	item->value.integer = value;
	item->type = IWOT_BOOLEAN;
	*result = item;

	return ec;			
}

IWOTERRORCODE iwot_util_create_var_value(const char *id, const char *name, const char *description, const char *type, const char *unit, int required, int minValue, int maxValue, char **enumerate, int enumerateCount, IWOTVALUEDEF **result)
{	
	IWOTERRORCODE ec = IWOT_EC_SUCCESS;
	int size = sizeof(IWOTVALUEDEF);
	IWOTVALUEDEF *value = 0;

	if (0 == id) { 
		ec = IWOT_EC_INVALID_DATA;
		goto err_out;
	}

	if (0 == (value = memory_alloc(size))) { 
		ec = IWOT_EC_INSUFFICIENT_MEMORY;
		goto err_out;
	}	
	memset(value, 0, size);

	if (0 != id && IWOT_EC_SUCCESS != (ec = iwot_util_copy_string(id, &value->id))) {
		goto err_out;
	}
	if (0 != name && IWOT_EC_SUCCESS != (ec = iwot_util_copy_string(name, &value->name))) {
		goto err_out;
	}
	if (0 != description && IWOT_EC_SUCCESS != (ec = iwot_util_copy_string(description, &value->description))) {
		goto err_out;
	}
	if (0 != type && IWOT_EC_SUCCESS != (ec = iwot_util_copy_string(type, &value->type))) {
		goto err_out;
	}
	if (0 != unit && IWOT_EC_SUCCESS != (ec = iwot_util_copy_string(unit, &value->unit))) {
		goto err_out;
	}				
	value->required = required;
	value->minValue = minValue;
	value->maxValue = maxValue;
  
	if (enumerateCount > 0) {		
		if (IWOT_EC_SUCCESS != (ec = iwot_util_copy_string_array(enumerate, enumerateCount, &value->enumerate))) {
			goto err_out;
		}						
		value->enumerateCount = enumerateCount; 
	}  
/*
	if (0 == strcmp(value->type, "integer")) {
		value->val.integer = *((int*)val);	    	    						
	} else if (0 == strcmp(value->type, "string")) {
		iwot_util_copy_string((char*)val, &value->val.string);    	    	    						
	} else if (0 == strcmp(value->type, "float")) {
		value->val.floating = *((float*)val); 	    	    						
	} else if (0 == strcmp(value->type, "boolean")) {
		value->val.integer = *((int*)val);
	}
*/  
	*result = value;
	return ec;

err_out:
	if (0 != value)	{
		iwot_util_free_var_value(&value);
	}
	return ec;
}

IWOTERRORCODE iwot_util_create_var_def(const char *id, const char *name, const char *description, int valuesCount, IWOTVARDEF **result)
{
	IWOTERRORCODE ec = IWOT_EC_SUCCESS;
	int size = sizeof(IWOTVARDEF);
	IWOTVARDEF *var = 0;

	if (0 == id) { 
		ec = IWOT_EC_INVALID_DATA;
		goto err_out;
	}

	if (0 == (var = memory_alloc(size))) { 
		ec = IWOT_EC_INSUFFICIENT_MEMORY;
		goto err_out;
	}

	memset(var, 0, size);

	if (0 != id && IWOT_EC_SUCCESS != (ec = iwot_util_copy_string(id, &var->id))) {
		goto err_out;
	}
	if (0 != name && IWOT_EC_SUCCESS != (ec = iwot_util_copy_string(name, &var->name))) {
		goto err_out;
	}
	if (0 != description && IWOT_EC_SUCCESS != (ec = iwot_util_copy_string(description, &var->description))) {
		goto err_out;
	}		

	if (valuesCount > 0) {
		if (0 == (var->values = memory_alloc(sizeof(IWOTVALUEDEF*) * valuesCount))) { 
			ec = IWOT_EC_INSUFFICIENT_MEMORY;
			goto err_out;
		}		
		var->valuesCount = valuesCount;		
	}

	*result = var;
	return ec;

err_out:
	if (0 != var) {
		iwot_util_free_var_def(&var);
	}
	return ec;  
}

IWOTERRORCODE iwot_util_create_model(const char *id, const char *classID, const char *createdAt, const char *updatedAt, const char *name, const char *description, char **tags, int tagsCount, void *customFields, void *links, int actionsCount, int eventsCount, int propertiesCount, void *system, IWOTMODEL **result)
{
	IWOTERRORCODE ec = IWOT_EC_SUCCESS;
	int size = sizeof(IWOTMODEL);
	IWOTMODEL *model = 0;

	if (0 == id) { 
		ec = IWOT_EC_INVALID_DATA;
		goto err_out;
	}

	if (0 == (model = memory_alloc(size))) { 
		ec = IWOT_EC_INSUFFICIENT_MEMORY;
		goto err_out;
	}	

	memset(model, 0, size);

	if (0 != id && IWOT_EC_SUCCESS != (ec = iwot_util_copy_string(id, &model->id))) {
		goto err_out;
	}
	if (0 != classID && IWOT_EC_SUCCESS != (ec = iwot_util_copy_string(classID, &model->classID))) {
		goto err_out;
	}
	if (0 != createdAt && IWOT_EC_SUCCESS != (ec = iwot_util_copy_string(createdAt, &model->createdAt))) {
		goto err_out;
	}
	if (0 != updatedAt && IWOT_EC_SUCCESS != (ec = iwot_util_copy_string(updatedAt, &model->updatedAt))) {
		goto err_out;
	}
	if (0 != name && IWOT_EC_SUCCESS != (ec = iwot_util_copy_string(name, &model->name))) {
		goto err_out;
	}
	if (0 != description && IWOT_EC_SUCCESS != (ec = iwot_util_copy_string(description, &model->description))) {
		goto err_out;
	}					

	if (tagsCount > 0) {
		if (IWOT_EC_SUCCESS != (ec = iwot_util_copy_string_array(tags, tagsCount, &model->tags))) {
			goto err_out;
		}							
		model->tagsCount = tagsCount;
	}

	if (actionsCount > 0) {
		if (0 == (model->actions = memory_alloc(sizeof(IWOTVARDEF*) * actionsCount))) { 
			ec = IWOT_EC_INSUFFICIENT_MEMORY;
			goto err_out;
		}			
		model->actionsCount = actionsCount;
	}

	if (eventsCount > 0) {
		if (0 == (model->events = memory_alloc(sizeof(IWOTVARDEF*) * eventsCount))) { 
			ec = IWOT_EC_INSUFFICIENT_MEMORY;
			goto err_out;
		}					
		model->eventsCount = eventsCount;
	}

	if (propertiesCount > 0) {
		if (0 == (model->properties = memory_alloc(sizeof(IWOTVARDEF*) * propertiesCount))) { 
			ec = IWOT_EC_INSUFFICIENT_MEMORY;
			goto err_out;
		}					
		model->propertiesCount = propertiesCount;
	}    

	*result = model;
	return ec;

err_out:
	if (0 != model) {
		iwot_util_free_model(&model);
	}
	return ec;  
}

IWOTERRORCODE iwot_util_create_config(const char *accessKey, const char *secretKey, const char *host, unsigned int keepAlive, const char *modelJSON, IWOTVAROBJECT *properties, IWOTCONFIG **result)
{	
	IWOTERRORCODE ec = IWOT_EC_SUCCESS;
	int size = sizeof(IWOTCONFIG);
	IWOTCONFIG *config = 0;
	
	if (0 == accessKey) { 
		ec = IWOT_EC_INVALID_DATA;
		goto err_out;
	}
	
	if (0 == (config = memory_alloc(size))) { 
		ec = IWOT_EC_INSUFFICIENT_MEMORY;
		goto err_out;
	}	

	memset(config, 0, size);

	if (0 != accessKey && IWOT_EC_SUCCESS != (ec = iwot_util_copy_string(accessKey, &config->accessKey))) {
		goto err_out;
	}					
	if (0 != secretKey && IWOT_EC_SUCCESS != (ec = iwot_util_copy_string(secretKey, &config->secretKey))) {
		goto err_out;
	}					
	if (0 != host && IWOT_EC_SUCCESS != (ec = iwot_util_copy_string(host, &config->host))) {
		goto err_out;
	}				
	if (0 != modelJSON && IWOT_EC_SUCCESS != (ec = iwot_util_copy_string(modelJSON, &config->modelJSON))) {
		goto err_out;
	}										
	config->keepAlive = keepAlive * 2 / 3;  
	config->properties = properties;  

	*result = config;
	return ec;
err_out:	
	if (0 != config) {
		iwot_util_free_config(&config);	
	}

	return ec;  	
}

void iwot_util_free_string(char **src)
{
	if (src != 0) {
		memory_free(*src);
		*src = 0;
	}		
}

void iwot_util_free_string_array(char ***src, int size)
{
	int i;
	char **s;
	if (*src != 0 && size > 0) {
		s = *src; 
		for (i = 0; i < size; i++, s++) {
			iwot_util_free_string(s);
		}
		memory_free(**src);
		**src = 0;
	}	
}

void iwot_util_free_var_value(IWOTVALUEDEF **value)
{
	if (*value != 0) {
		iwot_util_free_string(&(*value)->id);	
		iwot_util_free_string(&(*value)->name);
		iwot_util_free_string(&(*value)->description);
		iwot_util_free_string(&(*value)->type);
		iwot_util_free_string(&(*value)->unit);
		iwot_util_free_string_array(&(*value)->enumerate, (*value)->enumerateCount);
		
		memory_free(*value);
		*value = 0;		
	}	    
}

void iwot_util_free_var_def(IWOTVARDEF **var)
{	
	IWOTVALUEDEF **s;
	int i = 0;
		
	if (*var != 0) {
		iwot_util_free_string(&(*var)->id);
		iwot_util_free_string(&(*var)->name);
		iwot_util_free_string(&(*var)->description);
	
		if ((*var)->valuesCount > 0) {
			s = (*var)->values;
			for (i = 0; i < (*var)->valuesCount; i++, s++) {
				iwot_util_free_var_value(s);
			}
			memory_free((*var)->values);
		}		
		
		memory_free(*var);
		*var = 0;			
	}
}

void iwot_util_free_model(IWOTMODEL **model)
{
	IWOTVARDEF **s;
	int i = 0;
		
	if (*model != 0) {
		iwot_util_free_string(&(*model)->id);
		iwot_util_free_string(&(*model)->classID);
		iwot_util_free_string(&(*model)->createdAt);
		iwot_util_free_string(&(*model)->updatedAt);
		iwot_util_free_string(&(*model)->name);
		iwot_util_free_string(&(*model)->description);
		iwot_util_free_string_array(&(*model)->tags, (*model)->tagsCount);
	
		if ((*model)->actionsCount > 0) {
			s = (*model)->actions;
			for (i = 0; i < (*model)->actionsCount; i++, s++) {
				iwot_util_free_var_def(s);
			}
			memory_free((*model)->actions);
		}
		
		if ((*model)->eventsCount > 0) {
			s = (*model)->events;
			for (i = 0; i < (*model)->eventsCount; i++, s++) {
				iwot_util_free_var_def(s);
			}
			memory_free((*model)->events);
		}
		
		if ((*model)->propertiesCount > 0) {
			s = (*model)->properties;
			for (i = 0; i < (*model)->propertiesCount; i++, s++) {
				iwot_util_free_var_def(s);
			}
			memory_free((*model)->properties);
		}				
		
		memory_free(*model);
		*model = 0;			
	}
}

void iwot_util_free_config(IWOTCONFIG **config)
{
	if (*config != 0) {
		iwot_util_free_string(&(*config)->accessKey);
		iwot_util_free_string(&(*config)->secretKey);
		iwot_util_free_string(&(*config)->host);
		iwot_util_free_string(&(*config)->modelJSON);
			
		memory_free(*config);
		*config = 0;			
	}	
}

void iwot_util_free_var_object(IWOTVAROBJECT **object)
{
	IWOTVARGROUP **s;
	int i = 0;
		
	if (*object != 0) {
		iwot_util_free_string(&(*object)->identifier);
	
		if ((*object)->groupCount > 0) {
			s = (*object)->groups;
			for (i = 0; i < (*object)->groupCount; i++, s++) {
				iwot_util_free_var_group(s);
			}
			memory_free((*object)->groups);
		}		
		
		memory_free(*object);
		*object = 0;			
	}			
}

void iwot_util_free_var_group(IWOTVARGROUP **group)
{
	IWOTVARITEM **s;
	int i = 0;
		
	if (*group != 0) {
		iwot_util_free_string(&(*group)->identifier);
		iwot_util_free_string(&(*group)->timestamp);
		iwot_util_free_string(&(*group)->status);
		iwot_util_free_string(&(*group)->id);

		if ((*group)->itemCount > 0) {
			s = (*group)->items;
			for (i = 0; i < (*group)->itemCount; i++, s++) {
				iwot_util_free_var_item(s);
			}
			memory_free((*group)->items);
		}		
		
		memory_free(*group);
		*group = 0;			
	}		
}

void iwot_util_free_var_item(IWOTVARITEM **item)
{
	if (*item != 0) {
		iwot_util_free_string(&(*item)->key);
		
		if ((*item)->type == IWOT_STRING) {
			iwot_util_free_string(&(*item)->value.string); 
		}
		
		memory_free(*item);
		*item = 0;		
	}		
}

#if IWOT_OPT_ENABLE_FPU 
IWOTERRORCODE iwot_util_string_to_number(const char *src, int *result_i, double *result_lf)
{
	IWOTERRORCODE ec = IWOT_EC_SUCCESS;
	
	int cvt_i;
	char *cvt_s = 0;
	double cvt_lf;
	
	if (0 == (cvt_s = memory_alloc(sizeof(char) * (strlen(src) + 1)))) {
		ec = IWOT_EC_INSUFFICIENT_MEMORY;
		goto err_out;
	}	
	
	sscanf(src, "%d", &cvt_i);
	sprintf(cvt_s, "%d", cvt_i);
	if (0 == strcmp(src, cvt_s)) {
		*result_i = cvt_i;
		*result_lf = 0xFFFFFFFF;		
	} else {
		sscanf(src, "%lf", &cvt_lf);
		*result_lf = cvt_lf; 
		*result_i = 0xFFFFFFFF;		
	}

err_out:
	if (0 != cvt_s) {
		memory_free(cvt_s);
	}
	return ec;
}
#endif

IWOTERRORCODE iwot_util_string_to_integer(const char *src, int *result_i)
{
	IWOTERRORCODE ec = IWOT_EC_SUCCESS;
	
	int cvt_i;
	
	sscanf(src, "%d", &cvt_i);
	*result_i = cvt_i;

	return ec;
}

IWOTERRORCODE iwot_util_verify_object(IWOTMODEL *model, IWOTVAROBJECT *object)
{
#if IWOT_OPT_ENABLE_MQTT_MODEL		
	IWOTERRORCODE ec = IWOT_EC_SUCCESS;
	IWOTVARGOURPDEF **groupDef = 0, **groupDefStart = 0;
	IWOTVARGROUP **group = 0;
	IWOTVARITEMDEF **itemDef = 0; 
	IWOTVARITEM **item = 0;
	int groupDefCount = 0;
	int i, j;
	int m, n;
	int e;

	if(0 == strcmp("properties", object->identifier)) {
		groupDefStart = model->properties;
		groupDefCount = model->propertiesCount;
	} else if(0 == strcmp("actions", object->identifier)) {
		groupDefStart = model->actions;
		groupDefCount = model->actionsCount;
	} else if(0 == strcmp("events", object->identifier)) {
		groupDefStart = model->events;
		groupDefCount = model->eventsCount;
	} else {
		return IWOT_EC_INVALID_DATA;
	}

	for (i = 0, group = object->groups; i < object->groupCount; i++, group++) {
		for (m = 0, groupDef = groupDefStart; m < groupDefCount; m++, groupDef++) {
			if (0 == strcmp((*groupDef)->id, (*group)->identifier)) {
				for (n = 0, itemDef = (*groupDef)->values; n < (*groupDef)->valuesCount; n++, itemDef++) {
					for (j = 0, item = (*group)->items; j < (*group)->itemCount; j++, item++) {
						if (0 == strcmp((*itemDef)->id, (*item)->key)) {
							if ((*itemDef)->minValue != (*itemDef)->maxValue) {
								if (IWOT_INTEGER == (*item)->type) {
									if ((*item)->value.integer < (*itemDef)->minValue || (*item)->value.integer > (*itemDef)->maxValue) {
										return IWOT_EC_INVALID_DATA;
									}
								} else if (IWOT_FLOAT == (*item)->type) {
									if ((*item)->value.floating < (*itemDef)->minValue || (*item)->value.floating > (*itemDef)->maxValue) {
										return IWOT_EC_INVALID_DATA;
									}									
								}
							}
							if ((*itemDef)->enumerateCount > 0) {
								if (IWOT_STRING != (*item)->type) {
									return IWOT_EC_INVALID_DATA;
								}
								for (e = 0; e < (*itemDef)->enumerateCount; e++) {									
									if (0 == strcmp((*itemDef)->enumerate[e], (*item)->value.string)) {
										break;
									}
								}
								if (e == (*itemDef)->enumerateCount) {
									return IWOT_EC_INVALID_DATA;
								}
							}
							break;
						}
					}
					if (j == (*group)->itemCount && 1 == (*itemDef)->required){						
						return IWOT_EC_INVALID_DATA;
					}
				}
				break;
			}
		}
	}
#endif
	return IWOT_EC_SUCCESS;

}

int iwot_util_compare_string(char *str1, char*str2) 
{
	if (0 == str1 && 0 == str2) {
		return 0;
	} else if (0 == str1 && 0 != str2) {
		return strlen(str2); 
	} else if (0 != str1 && 0 == str2) {
		return strlen(str1);
	}
	return strcmp(str1, str2);	
}

int iwot_util_compare_string_array(char **str1, int size1, char **str2, int size2) 
{
	int i = 0;
	int j = 0;
	int find  = 0; 
	char *checked = 0;
	
	if (0 == str1 && 0 == str2) {
		return 0;
	} else if (0 == str1 && 0 != str2) {
		return 1;
	} else if (0 != str1 && 0 == str2) {
		return 1;
	}
	if (size1 != size2) {
		return 1;
	}
	
	if (0 == (checked = memory_alloc(sizeof(char) * size1))) {
		return 1;
	}
	memset(checked, 0, sizeof(char) * size1);
	
	for(i = 0; i < size1; i++) {
		find = 0;
		for(j = 0; j < size2; j++) {
			if (0 == checked[j]) {
				if(0 == iwot_util_compare_string(str1[i], str2[j])) {
					find = 1;
					checked[j] = 1;
					break;
				}				
			}
		}
		if (0 == find) {
			memory_free(checked);
			return 1;
		}
	}
	
	memory_free(checked);
	return 0;	
}

int iwot_util_compare_var_item_def(IWOTVALUEDEF *var1, IWOTVALUEDEF *var2) 
{
	if (0 == var1 && 0 == var2) {
		return 0;
	} else if (0 == var1 && 0 != var2) {
		return 1;
	} else if (0 != var1 && 0 == var2) {
		return 1;
	}

	if (0 != iwot_util_compare_string(var1->id, var2->id) ||
		0 != iwot_util_compare_string(var1->name, var2->name) ||
		0 != iwot_util_compare_string(var1->description, var2->description) ||
		0 != iwot_util_compare_string(var1->type, var2->type) ||
		0 != iwot_util_compare_string(var1->unit, var2->unit) ||
		var1->required != var2->required ||
		var1->minValue != var2->minValue ||
		var1->maxValue != var2->maxValue ||
		0 != iwot_util_compare_string_array(var1->enumerate, var1->enumerateCount, var2->enumerate, var2->enumerateCount)) {
		return 1;
	}
	
	return 0;	
}

int iwot_util_compare_var_item_def_array(IWOTVALUEDEF **var1, int size1, IWOTVALUEDEF **var2, int size2) 
{
	int i = 0;
	int j = 0;
	int find  = 0; 
	char *checked = 0;
	
	if (0 == var1 && 0 == var2) {
		return 0;
	} else if (0 == var1 && 0 != var2) {
		return 1;
	} else if (0 != var1 && 0 == var2) {
		return 1;
	}
	if (size1 != size2) {
		return 1;
	}
	
	if (0 == (checked = memory_alloc(sizeof(char) * size1))) {
		return 1;
	}
	memset(checked, 0, sizeof(char) * size1);
		
	for(i = 0; i < size1; i++) {
		find = 0;
		for(j = 0; j < size2; j++) {
			if (0 == checked[j]) {
				if(0 == iwot_util_compare_var_item_def(var1[i], var2[j])) {
					find = 1;
					checked[j] = 1;
					break;
				}				
			}
		}
		if (0 == find) {
			memory_free(checked);
			return 1;
		}
	}
	
	memory_free(checked);	
	return 0;	
}

int iwot_util_compare_var_group_def(IWOTVARGOURPDEF *var1, IWOTVARGOURPDEF *var2) 
{
	if (0 == var1 && 0 == var2) {
		return 0;
	} else if (0 == var1 && 0 != var2) {
		return 1;
	} else if (0 != var1 && 0 == var2) {
		return 1;
	}

	if (0 != iwot_util_compare_string(var1->id, var2->id) ||
		0 != iwot_util_compare_string(var1->name, var2->name) ||
		0 != iwot_util_compare_string(var1->description, var2->description) ||
		0 != iwot_util_compare_var_item_def_array(var1->values, var1->valuesCount, var2->values, var2->valuesCount)) {
		return 1;
	}
	
	return 0;	
}

int iwot_util_compare_var_group_def_array(IWOTVARGOURPDEF **var1, int size1, IWOTVARGOURPDEF **var2, int size2) 
{
	int i = 0;
	int j = 0;
	int find  = 0; 
	char *checked = 0;
	
	if (0 == var1 && 0 == var2) {
		return 0;
	} else if (0 == var1 && 0 != var2) {
		return 1;
	} else if (0 != var1 && 0 == var2) {
		return 1;
	}
	if (size1 != size2) {
		return 1;
	}
	
	if (0 == (checked = memory_alloc(sizeof(char) * size1))) {
		return 1;
	}
	memset(checked, 0, sizeof(char) * size1);
	
	for(i = 0; i < size1; i++) {
		find = 0;
		for(j = 0; j < size2; j++) {
			if (0 == checked[j]) {
				if(0 == iwot_util_compare_var_group_def(var1[i], var2[j])) {
					find = 1;
					checked[j] = 1;
					break;
				}				
			}
		}
		if (0 == find) {
			memory_free(checked);
			return 1;
		}
	}
	
	memory_free(checked);		
	return 0;	
}

int iwot_util_compare_model(IWOTMODEL *model1, IWOTMODEL *model2)
{
#if IWOT_OPT_ENABLE_MQTT_MODEL	
	if (0 == model1 && 0 == model2) {
		return 0;
	} else if (0 == model1 && 0 != model2) {
		return 1;
	} else if (0 != model1 && 0 == model2) {
		return 1;
	} 
	
	if (0 != iwot_util_compare_string(model1->id, model2->id) ||
	    0 != iwot_util_compare_string(model1->classID, model2->classID) ||
		0 != iwot_util_compare_string(model1->createdAt, model2->createdAt) ||
		0 != iwot_util_compare_string(model1->updatedAt, model2->updatedAt) ||
		0 != iwot_util_compare_string(model1->name, model2->name) ||
		0 != iwot_util_compare_string(model1->description, model2->description) ||
		0 != iwot_util_compare_string_array(model1->tags, model1->tagsCount, model2->tags, model2->tagsCount) ||
		0 != iwot_util_compare_var_group_def_array(model1->actions, model1->actionsCount, model2->actions, model2->actionsCount) ||
		0 != iwot_util_compare_var_group_def_array(model1->events, model1->eventsCount, model2->events, model2->eventsCount) ||
		0 != iwot_util_compare_var_group_def_array(model1->properties, model1->propertiesCount, model2->properties, model2->propertiesCount)) {
		return 1;
	}		
#endif
	return 0;
}