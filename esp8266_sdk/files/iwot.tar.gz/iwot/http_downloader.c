#include <stdio.h> 
#include <stdlib.h>
#include <string.h> 
#include "http_downloader.h"
#include "http_wrapper.h"
#include "json_parser.h"
#include "system_wrapper.h"

char *keySvrHost = "192.168.22.3";
int  keySvrPort = 9107;
char *crtPath = "/downloadClientCertification";
char *keyPath = "/downloadClientKey";
char *brkrPath = "/getMqttConnectOpt";
char *pkgPath = "/getConnectPackage?id=";
char *ruleEngPath = "ruleEngine/token?client-id=node-red-sdk&scope=*";  

#if IWOT_OPT_ENABLE_SSL
char *mqttProtocol = "mqtts";
#else
char *mqttProtocol = "mqtt";
#endif

/*IWOTERRORCODE download_certificate(char *accessKey, char *secretKey, char *host, char **broker, int *port, char **protocol, char **token) 
{
  return download_certificate_ex(accessKey, secretKey, host, broker, port, protocol, token, 0, 0);

IWOTERRORCODE ec = IWOT_EC_SUCCESS;  
  char *body = 0;
  HTTPCONFIG httpConfig;
  CONNECTOPT *opt;

  httpConfig.host = (host == NULL ? keySvrHost : host);
  httpConfig.port = keySvrPort;
  httpConfig.accessKey = accessKey;
  httpConfig.secretKey = secretKey;  
  httpConfig.protocol = mqttProtocol;
  httpConfig.path = brkrPath;

  if (IWOT_EC_SUCCESS != (ec = http_request(&httpConfig, &body))) {
    goto err_out;
  }

  if (IWOT_EC_SUCCESS != (ec = json_parse_connect_opt(body, &opt))) {
    goto err_out;
  }  

  *broker = opt->host;
  *port = opt->port;
  *protocol = opt->protocol;
  *token = opt->token;  
 
err_out:  
  if (body != 0) {
    free(body);  
  }
  return ec;  
}  */

IWOTERRORCODE download_certificate(char *accessKey, char *secretKey, char *host, char **broker, int *port, char **protocol, char **token, char **certificate, char **key) 
{
  IWOTERRORCODE ec = IWOT_EC_SUCCESS;  
  char *body = 0;
  char *c = 0;
  char *k = 0;
  HTTPCONFIG httpConfig;
  CONNECTOPT *opt;
  
  httpConfig.host = (host == 0 ? keySvrHost : host);
  httpConfig.port = keySvrPort;
  httpConfig.accessKey = accessKey;
  httpConfig.secretKey = secretKey;  
  httpConfig.protocol = mqttProtocol;
  httpConfig.path = (char*)brkrPath;

  if (IWOT_EC_SUCCESS != (ec = http_request(&httpConfig, &body, 512, 0))) {
    goto err_out;
  }

  if (IWOT_EC_SUCCESS != (ec = json_parse_connect_opt(body, &opt))) {
    goto err_out;
  }  

  httpConfig.protocol = 0;

#if IWOT_OPT_ENABLE_SSL
  if (0 != certificate) {
    httpConfig.path = (char*)crtPath;
    if (IWOT_EC_SUCCESS != (ec = http_request(&httpConfig, &c, 2048, 0))) {
      goto err_out;
    }    
  }

  if (0 != key) {
    httpConfig.path = (char*)keyPath;
    if (IWOT_EC_SUCCESS != (ec = http_request(&httpConfig, &k, 2048, 0))) {
      goto err_out;
    }
  }

  if (0 != certificate) { 
    *certificate = c;
  }
  if (0 != key) {
    *key = k;
  }  
#endif

  *broker = opt->host;
  *port = opt->port;
  *protocol = opt->protocol;
  *token = opt->token; 

 
err_out:  
  if (body != 0) {
    free(body);  
  }

  if (ec != IWOT_EC_SUCCESS) {
    if (k != 0) {
      free(k);  
    }
    if (c != 0) {
      free(c);  
    }    
  }  
  return ec;  
}

IWOTERRORCODE download_connect_package(char *accessKey, char *secretKey, char *host, char *id, char **broker, int *port, char **protocol, char **token, char **certificate, char **key, IWOTMODEL **model) 
{
  IWOTERRORCODE ec = IWOT_EC_SUCCESS;  
  char *body = 0;
  char *c = 0;
  char *k = 0;
  HTTPCONFIG httpConfig;
  CONNECTOPT *opt = 0;
  IWOTMODEL *m = 0;
  
  httpConfig.host = (host == 0 ? keySvrHost : host);
  httpConfig.port = keySvrPort;
  httpConfig.accessKey = accessKey;
  httpConfig.secretKey = secretKey;  
  httpConfig.protocol = mqttProtocol;
  httpConfig.path = 0;

  if (IWOT_EC_SUCCESS != (ec = iwot_util_concat_string(pkgPath, strlen(pkgPath), id, strlen(id), &httpConfig.path))) {
    goto err_out;
  }
  
#if IWOT_OPT_ENABLE_SSL  
  if (IWOT_EC_SUCCESS != (ec = http_request(&httpConfig, &body, IWOT_OPT_MAX_MODEL_SIZE + 2048, 0))) {
#else    
  if (IWOT_EC_SUCCESS != (ec = http_request(&httpConfig, &body, IWOT_OPT_MAX_MODEL_SIZE + 64, 0))) {
#endif        
    goto err_out;
  }
  
#if IWOT_OPT_ENABLE_SSL  
  if (IWOT_EC_SUCCESS != (ec = json_parse_connect_package(body, &opt, &c, &k, &m))) {
#else 
  if (IWOT_EC_SUCCESS != (ec = json_parse_connect_package(body, &opt, 0, 0, &m))) {
#endif   
    goto err_out;
  }  

  *broker = opt->host;
  *port = opt->port;
  *protocol = opt->protocol;
  *token = opt->token; 
  *certificate = c;
  *key = k;
  *model = m;
 
err_out:  
  if (body != 0) {
    free(body);  
  }

  if (ec != IWOT_EC_SUCCESS) {
    if (k != 0) {
      free(k);  
    }
    if (c != 0) {
      free(c);  
    }  
    if (m != 0) {
      iwot_util_free_model(&m);
    }  
  }  
  
  if (0 != httpConfig.path) {
    iwot_util_free_string(&httpConfig.path);
  }
  
  return ec;  
}    

IWOTERRORCODE download_model(char *accessKey, char *secretKey, char *host, char *id, IWOTMODEL **model) 
{
  IWOTERRORCODE ec = IWOT_EC_SUCCESS;  
  char *body = 0;
  HTTPCONFIG httpConfig;  
  int len = sizeof(char) * (strlen(id) + 8); 
  
  httpConfig.host = (host == NULL ? keySvrHost : host);
  httpConfig.port = keySvrPort;
  httpConfig.accessKey = accessKey;
  httpConfig.secretKey = secretKey;  
  httpConfig.protocol = 0;
  if (0 == (httpConfig.path = (char*)memory_alloc(len))) {
    ec = IWOT_EC_INSUFFICIENT_MEMORY;
    goto err_out;
  }   
  memset(httpConfig.path, 0, len);
  sprintf(httpConfig.path, "/%s/model", id);

  if (IWOT_EC_SUCCESS != (ec = http_request(&httpConfig, &body, IWOT_OPT_MAX_MODEL_SIZE, 0))) {
    goto err_out;
  }

  if (IWOT_EC_SUCCESS != (ec = json_parse_model(body, model))) {
    goto err_out;
  }  
  
err_out:
  if (0 != body) {
    iwot_util_free_string(&body);  
  }
  if (0 != httpConfig.path) {
    memory_free(httpConfig.path);
  }
  return ec;  
}  

IWOTERRORCODE download_firmware (char *accessKey, char *secretKey, char *host, char *url, const char *dst)
{
  IWOTERRORCODE ec = IWOT_EC_SUCCESS;  
  char *body = 0;
  HTTPCONFIG httpConfig;  
  FILE *pf = 0;
  unsigned int len = 0;
  
  httpConfig.host = (host == NULL ? keySvrHost : host);
  httpConfig.port = keySvrPort;
  httpConfig.accessKey = accessKey;
  httpConfig.secretKey = secretKey;  
  httpConfig.protocol = 0;
  httpConfig.path = url;

  if (IWOT_EC_SUCCESS != (ec = http_request(&httpConfig, &body, 32768, &len))) {
    goto err_out;
  }

  if (0 == (pf = fopen(dst,"wb"))) {
    goto err_out;
  }

  fwrite(body, 1, len, pf);  
  
err_out:
  if (0 != body) {
    iwot_util_free_string(&body);  
  }
  if (0 != pf) {
    fclose(pf);
  }
  return ec;    
}




