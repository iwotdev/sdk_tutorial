#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "MQTT8266.h"
#include "http_wrapper.h"
#include "system_wrapper.h"

int _http_parse_body (char *data, char **result)
{
  char *token = 0;
  const char *seq = "\n";
  int len = -1;
  char *body = 0;
  int start = 0;
  int trunked = 0;
  char *trunk = 0;
  int trunkTotalLen = 0;

  token = strtok(data, seq);
  while (0 != token) {
    start += (strlen(token) + 1);
    if ('\r' == token[0]) {
      if (1 == trunked) {
        do {
          trunk = &data[start];
          token = strtok(trunk, seq);
          start += (strlen(token) + 1);
          sscanf(token, "%x\r", &len);
          
          if (len == 0) {
            *result = body;        
            return trunkTotalLen;            
          }

          if (trunkTotalLen > 0) {
            return -1; //Not implemented yet...
          }
          
          token = &data[start];          
          if(IWOT_EC_SUCCESS != iwot_util_copy_string_partial(token, &body, 0, len)) {
            return -1;
          }
          trunkTotalLen += len;
          start += (len + 2);
          
        } while (1);        
      } else {
        token = &data[start]; //strtok(NULL, "");
        if(0 < len && 0 != token && IWOT_EC_SUCCESS == iwot_util_copy_string_partial(token, &body, 0, len)) {
          *result = body;                  
          return len;
        }        
      }
      return -1;
    } else {
      if (0 == strncmp("Content-Length: ", token, 16)) {
        sscanf(token, "Content-Length: %d\r", &len);
      } else if (0 == strncmp("Transfer-Encoding: chunked\r", token, 26)) {
        trunked = 1;
      }
    }
    token = strtok(NULL, seq);
  }

  return -1;
}

IWOTERRORCODE _http_socket_client(HTTPCONFIG *config, char **result, unsigned int maxLen, unsigned int *resultLen)
{
  IWOTERRORCODE ec = IWOT_EC_SUCCESS;

  Network netConn;
  int net_err = 0;
  char req[256];
  size_t reqLen = 0;
  size_t sent = 0;
  int rc = 0;
  size_t resLen = 0; 
  char *data = NULL; 
  char *body = NULL;
  unsigned int bodyLen = 0; 

  if (0 != config->accessKey && 0 != config->protocol) {
    sprintf(req, "GET %s HTTP/1.1\r\nHost: %s:%d\r\naccessKey: %s\r\nprotocol: %s\r\n\r\n", config->path, config->host, config->port, config->accessKey, config->protocol);  
  } else if (0 != config->accessKey) {
    sprintf(req, "GET %s HTTP/1.1\r\nHost: %s:%d\r\naccessKey: %s\r\n\r\n", config->path, config->host, config->port, config->accessKey);
  } else {
    sprintf(req, "GET %s HTTP/1.1\r\nHost: %s:%d\r\n\r\n", config->path, config->host, config->port);
  }

  reqLen = strlen(req);
  memset(&netConn, 0, sizeof(Network));

  if (0 == (data = (char*)memory_alloc(maxLen))) {
    ec = IWOT_EC_INSUFFICIENT_MEMORY;
    goto err_out;
  }  
  memset(data, 0, maxLen);

  NetworkInit(&netConn, 0, 0);
  if(0 != (net_err = NetworkConnect (&netConn, config->host, config->port))) {
    debug_log("NetworkConnect error. error code = %d", net_err);
    ec = IWOT_EC_HTTP_CONNECT_FAILED;
    goto err_out;
  }  

  while (sent < reqLen) {
      rc = netConn.mqttwrite(&netConn, req, reqLen, IWOT_OPT_TCP_TIMEOUT);
      if (rc < 0)  // there was an error writing the data
          break;
      sent += rc;
  }

  rc = netConn.mqttread(&netConn, data, maxLen, IWOT_OPT_TCP_TIMEOUT);
  
  if (0 == strlen(data)) {
    ec = IWOT_EC_INVALID_DATA;
    goto err_out;  
  }

  if (0 > (bodyLen = _http_parse_body(data, &body))) {
    ec = IWOT_EC_INSUFFICIENT_MEMORY;
    goto err_out;
  }  

  *result = body;
  if (resultLen) {
    *resultLen = bodyLen;
  }  

err_out:
  if (0 != netConn.my_socket) {
    NetworkDisconnect(&netConn);    
  }
  if (NULL != data) {
    memory_free(data);
  }

  return ec;
}

IWOTERRORCODE http_request(HTTPCONFIG *config, char **result, unsigned int maxLen, unsigned int *resultLen)
{
  IWOTERRORCODE ec = IWOT_EC_SUCCESS;

  for (int i = 0; i < IWOT_OPT_MAX_NETWORK_RETRY; i++) {
    if (IWOT_EC_SUCCESS == (ec = _http_socket_client(config, result, maxLen, resultLen))) {
      break;
    }
    debug_log("Fail to connect HTTP. try again(%d)", i);
  }
  
  return ec;
}

