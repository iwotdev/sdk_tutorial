#include <string.h>
#include "MQTTClient.h"
#include "mqtt_wrapper.h"
#include "json_parser.h"
#include "system_wrapper.h"
#include "crypto.h"

typedef struct _mqttsub {
	int length; //mqttSubLength;
	int used; //mqttSubUsed;
	char **topic; //**mqttSubTopic;	
	MQTTMSGCALLBACK *callback; //*mqttSubCallback;
	MQTTCLIENT **client; //**mqttSubClient;
} MQTTSUB;

MQTTSUB *singletonMqttSub = 0;

/*void _mqtt_delete_callback_array()
{
	if (0 != mqttSubTopic) {
		memory_free(mqttSubTopic);
		mqttSubTopic = 0;
	}
	if (0 != mqttSubCallback) {
		memory_free(mqttSubCallback);
		mqttSubCallback = 0;
	}
	if (0 != mqttSubClient) {
		memory_free(mqttSubClient);
		mqttSubClient = 0;
	}
	mqttSubLength = 0;
}

IWOTERRORCODE _mqtt_create_callback_array(int size)
{
	IWOTERRORCODE ec = IWOT_EC_SUCCESS;	

	if (0 == mqttSubTopic) {
		if (0 == (mqttSubTopic = (char **)memory_alloc(sizeof(char*) * mqttSubLength))) {		
			ec = IWOT_EC_INSUFFICIENT_MEMORY;
			goto err_out;
		}	

		if (0 == (mqttSubCallback = (MQTTMSGCALLBACK *)memory_alloc(sizeof(MQTTMSGCALLBACK) * mqttSubLength))) {		
			ec = IWOT_EC_INSUFFICIENT_MEMORY;
			goto err_out;
		}

		if (0 == (mqttSubClient = (MQTTCLIENT **)memory_alloc(sizeof(MQTTCLIENT*) * mqttSubLength))) {		
			ec = IWOT_EC_INSUFFICIENT_MEMORY;
			goto err_out;
		}		
	}

err_out:
	if (IWOT_EC_SUCCESS != ec) {
		_mqtt_delete_callback_array();
	} 
	return ec;	
}*/

void _mqttsub_remove_client(MQTTCLIENT *client, char *topic) 
{	
	MQTTSUB *sub = singletonMqttSub;		
	int i = 0;

	if (0 != sub) {
		for (i = 0; i < sub->used; i++) {
			if (sub->client[i] == client) {
				if (0 == topic || 0 == strcmp(sub->topic[i], topic)) {
					iwot_util_free_string(&sub->topic[i]);
					sub->client[i] = 0;					
					sub->callback[i] = 0;					
				}
			}
		}
	}
}

void _mqttsub_free(MQTTSUB **result) 
{	
	MQTTSUB *sub = *result;		

	if (0 != sub) {
		if (0 != sub->topic) {
			memory_free(sub->topic);
		}
		if (0 != sub->callback) {
			memory_free(sub->callback);
		}
		if (0 != sub->client) {
			memory_free(sub->client);
		}		
		memory_free(sub);
	}
	*result = 0;
}

IWOTERRORCODE _mqttsub_alloc(MQTTSUB **result, int length) 
{
	IWOTERRORCODE ec = IWOT_EC_SUCCESS;
	MQTTSUB *sub = 0;		
	if (0 == (sub = (MQTTSUB*)memory_alloc(sizeof(MQTTSUB)))) {
		ec = IWOT_EC_INSUFFICIENT_MEMORY;
		goto err_out;
	}
	memset(sub, 0, sizeof(MQTTSUB));
	sub->length = length;
	if (0 == (sub->topic = (char**)memory_alloc(sizeof(char*) * sub->length))) {
		ec = IWOT_EC_INSUFFICIENT_MEMORY;
		goto err_out;
	}		
	if (0 == (sub->callback = (MQTTMSGCALLBACK*)memory_alloc(sizeof(MQTTMSGCALLBACK) * sub->length))) {
		ec = IWOT_EC_INSUFFICIENT_MEMORY;
		goto err_out;
	}		
	if (0 == (sub->client = (MQTTCLIENT**)memory_alloc(sizeof(MQTTCLIENT*) * sub->length))) {
		ec = IWOT_EC_INSUFFICIENT_MEMORY;
		goto err_out;
	}			
	*result = sub;

	return ec;
err_out:
	_mqttsub_free(&sub);
	return ec;
}

IWOTERRORCODE _mqttsub_get(MQTTSUB **result)
{	
	IWOTERRORCODE ec = IWOT_EC_SUCCESS;
	MQTTSUB *sub = singletonMqttSub;	
	MQTTSUB *subNew = 0;
	int i = 0;

	if (0 == sub) {
		if(IWOT_EC_SUCCESS == (ec = _mqttsub_alloc(&sub, 10))) {
			singletonMqttSub = sub;	
		}		
	} else if (sub->length == sub->used + 1) {
		if(IWOT_EC_SUCCESS == (ec = _mqttsub_alloc(&subNew, sub->length + 10))) {
			subNew->length = sub->length;
			subNew->used = sub->used;
			for (i = 0; i < sub->used; i++) {
				subNew->topic[i] = sub->topic[i];
				subNew->callback[i] = sub->callback[i];
				subNew->client[i] = sub->client[i];
			}
			_mqttsub_free(&sub);
			sub = subNew;
			singletonMqttSub = subNew;	
		}
	}
	*result = sub;

	return ec;
}

void _mqtt_message_arrived(MessageData* md)
{	
    MQTTMessage *message = md->message;
    char *payload = 0;
    char *topic = 0;
    char *topicNew = 0;
    MQTTSUB *mqttSub = 0;
    int qos = 0;
    char *plain = 0;

	if(IWOT_EC_SUCCESS != _mqttsub_get(&mqttSub)) {
		goto err_out;
	}    

    if(IWOT_EC_SUCCESS != iwot_util_copy_string_partial((char*)message->payload, &payload, 0, message->payloadlen)) {
    	goto err_out;
    }    

	if (md->topicName->cstring) {
		topic = md->topicName->cstring;	
	} else {
	    if(IWOT_EC_SUCCESS != iwot_util_copy_string_partial((char*)md->topicName->lenstring.data, &topicNew, 0, md->topicName->lenstring.len)) {
	    	goto err_out;
	    }	
	    topic = topicNew;	
	}

    //debug_log("_mqtt_message_arrived. topic is %s. payload is %s", topic, payload);

    for(int i = 0; i < mqttSub->used; i++) {
    	if (0 != mqttSub->topic[i] && 0 == strcmp(mqttSub->topic[i], topic)) {    		
    		IWOTVAROBJECT *object = 0;
  		    if (payload[0] == 0x7B) {
  		    	if(IWOT_EC_SUCCESS == json_parse_var_object(payload, &object, &qos)) {
	    			mqttSub->callback[i](topic, payload, object, qos);	
	    			iwot_util_free_var_object(&object);				
	    		}		    	
    		} else {
    			if(IWOT_EC_SUCCESS == crypto_aes256_decode(mqttSub->client[i]->plkey, payload, &plain)) {
	  		    	if(IWOT_EC_SUCCESS == json_parse_var_object(plain, &object, &qos)) {
		    			mqttSub->callback[i](topic, plain, object, qos);	
		    			iwot_util_free_var_object(&object);				
		    		}		
		    		memory_free(plain);    	
		    		plain = 0;
    			}
    		}    		
    	}
    } 

err_out:
	if (0 != payload) {
		iwot_util_free_string(&payload);
	}    
	if (0 != topicNew) {
		iwot_util_free_string(&topicNew);
	}  	
}

void _mqtt_delete_connect(MQTTCONNECT **client)
{
	MQTTCONNECT *connect = *client;

	if (0 != connect) {
		if (0 != connect->client) {
			MQTTDisconnect(connect->client);
			memory_free(connect->client);
			connect->client = 0;
		}

		if (0 != connect->ipstack) {
			NetworkDisconnect(connect->ipstack);
			memory_free(connect->ipstack);
			connect->ipstack = 0;
		}

		memory_free(*client);
		(*client) = 0;
	}
}

IWOTERRORCODE mqtt_create_client(MQTTCONFIG *config, MQTTCLIENT **result)
{	
	IWOTERRORCODE ec = IWOT_EC_SUCCESS;
	MQTTCONNECT *connect = 0;
	MQTTPacket_connectData data = MQTTPacket_connectData_initializer;       
	MQTTCLIENT *mqttClient = 0;
	int i = 0, retry = IWOT_OPT_MAX_NETWORK_RETRY;		

	if (0 == (connect = (MQTTCONNECT *)memory_alloc(sizeof(MQTTCONNECT)))) {		
		ec = IWOT_EC_INSUFFICIENT_MEMORY;
		goto err_out;
	}	    		  		
	if (0 == (connect->ipstack = (Network *)memory_alloc(sizeof(Network)))) {		
		ec = IWOT_EC_INSUFFICIENT_MEMORY;
		goto err_out;
	}	    		
	if (0 == (connect->client = (MQTTClient *)memory_alloc(sizeof(MQTTClient)))) {		
		ec = IWOT_EC_INSUFFICIENT_MEMORY;
		goto err_out;
	}	    	
	if (0 == (mqttClient = (MQTTCLIENT *)memory_alloc(sizeof(MQTTCLIENT)))) {		
		ec = IWOT_EC_INSUFFICIENT_MEMORY;
		goto err_out;
	}	
	if (0 == (mqttClient->alive = (char *)memory_alloc(sizeof(char) * (strlen(config->token) + strlen(config->id) + 7)))) { 		
		ec = IWOT_EC_INSUFFICIENT_MEMORY;
		goto err_out;
	}	
	sprintf(mqttClient->alive, "%s/%s/life", config->token, config->id);			

	crypto_aes256_create_key(config->secretKey, &mqttClient->plkey);

	if (0 != config->cert && 0 != config->key) {
		debug_log("SSL enabled.");
	}

	NetworkInit(connect->ipstack, config->cert, config->key);	
	MQTTClientInit(connect->client, connect->ipstack, IWOT_OPT_TCP_TIMEOUT, connect->sendbuf, sizeof(connect->sendbuf), connect->readbuf, sizeof(connect->readbuf));	

	for (i = 0; i < retry; i++) {
		if (0 == NetworkConnect(connect->ipstack, config->host, config->port)) {
			break;
		}	
		debug_log("NetworkConnect failed. Try again. (%d)", i);
	}

	if (i == retry) {
		ec = IWOT_EC_MQTT_CONNECT_FAILED;
		goto err_out;		
	}
	
	data.MQTTVersion = 3;
	data.clientID.cstring = config->clientID;
	data.willFlag = 1;
	data.keepAliveInterval = config->keepAlive == 0 ? 60 : config->keepAlive;
	data.will.topicName.cstring = mqttClient->alive;
	data.will.message.cstring = "{\"cycle\":\"lastwill\"}";
	/*data.will.topicName.lenstring.data = lastWillTopic;
	data.will.topicName.lenstring.len = strlen(lastWillTopic);
	data.will.message.lenstring.data = lastWillMessage;
	data.will.message.lenstring.len = strlen(lastWillMessage);*/

	for (i = 0; i < retry; i++) {
		if (0 == MQTTConnect(connect->client, &data)) {
			break;
		}	
		debug_log("MQTTConnect failed. Try again. (%d)", i);
	}

	if (i == retry) {
		ec = IWOT_EC_MQTT_CONNECT_FAILED;
		goto err_out;
	}

	mqttClient->connect = connect;
	*result = mqttClient;

err_out:
	if(ec != IWOT_EC_SUCCESS) {
		if (0 != connect) {
			_mqtt_delete_connect(&connect);
		}
		if (0 != mqttClient) {	
			if (0 != mqttClient->alive) {
				memory_free(mqttClient->alive);	
			}
			if (0 != mqttClient->plkey) {
				crypto_aes256_free_key(&mqttClient->plkey);
			}
			memory_free(mqttClient);
		}
	}
	return ec;
}

IWOTERRORCODE mqtt_subscribe_topic(MQTTCLIENT *client, char *topic, int qos, MQTTMSGCALLBACK callback) 
{
	IWOTERRORCODE ec = IWOT_EC_SUCCESS;
	enum QoS q = QOS2;
	MQTTCONNECT *connect = client->connect;
	MQTTSUB *mqttSub = 0;
	switch(qos) {
		case 0:
			q = QOS0;
			break;
		case 1:
			q = QOS1;
			break;			
	}

#if IWOT_OPT_ENABLE_MQTT_QOS == 0
	q = QOS0; 
#endif	

	//_mqtt_create_callback_array(10);
	if (IWOT_EC_SUCCESS != (ec = _mqttsub_get(&mqttSub))) {
		goto err_out;
	}	

	if(IWOT_EC_SUCCESS != (ec = iwot_util_copy_string(topic, &mqttSub->topic[mqttSub->used]))) {
		goto err_out;		
	}
	
	if (0 != MQTTSubscribe(connect->client, topic, q, _mqtt_message_arrived)) {
		ec = IWOT_EC_MQTT_SUBSCRIBE_FAILED;
		goto err_out;
	}	

	mqttSub->callback[mqttSub->used] = callback;
	mqttSub->client[mqttSub->used] = client;
	mqttSub->used++;

	debug_log("subscribe MQTT topic %s successfully. total subscription is %d.", topic, mqttSub->used);

	return ec;

err_out:
	if (0 != mqttSub->topic[mqttSub->used]) {
		iwot_util_free_string(&mqttSub->topic[mqttSub->used]);
	}
	return ec;
}

IWOTERRORCODE mqtt_publish_topic(MQTTCLIENT *client, char *topic, int qos, char *payload) 
{
	IWOTERRORCODE ec = IWOT_EC_SUCCESS;

	MQTTMessage message;
	MQTTCONNECT *connect = client->connect;
	char *cipher = 0;

	enum QoS q = QOS2;
	switch(qos) {
		case 0:
			q = QOS0;
			break;
		case 1:
			q = QOS1;
			break;			
	}

#if IWOT_OPT_ENABLE_MQTT_QOS == 0
	q = QOS0; 
#endif		

	if(IWOT_EC_SUCCESS == (ec = crypto_aes256_encode(client->plkey, payload, &cipher))) {
		message.qos = q;
		message.retained = 0;
		message.dup = 0;
		message.payload = (void*)cipher;
		message.payloadlen = strlen(cipher);

		if(0 != MQTTPublish(connect->client, topic, &message)) {
			ec = IWOT_EC_MQTT_PUBLISH_FAILED;
		} else {
			debug_log("publish MQTT topic %s successfully.", topic);
		}

		memory_free(cipher);
	}

	return ec;	
}

IWOTERRORCODE mqtt_poll_message(MQTTCLIENT *client) {
	IWOTERRORCODE ec = IWOT_EC_SUCCESS;
	MQTTCONNECT *connect = client->connect;

	if(0 == connect->client->isconnected) {
		ec = IWOT_EC_MQTT_CONNECT_FAILED;
		debug_log("MQTT disconnected");
	} else {
		MQTTYield(connect->client, 1000);
	}

	return ec;
}

#if IWOT_OPT_ENABLE_MQTT_THREAD
void mqtt_poll_message_thread(MQTTCLIENT *client)
{
	MQTTCONNECT *connect = client->connect;

	MQTTStartTask(connect->client);
}
#endif

void mqtt_unsubscribe_topic(MQTTCLIENT *client, char *topic) 
{
	MQTTCONNECT *connect = client->connect;

	MQTTUnsubscribe(connect->client, topic);	

	_mqttsub_remove_client(client, topic);
}

void mqtt_delete_client(MQTTCLIENT **client)
{
	MQTTCONNECT *connect = (*client)->connect;

	if (0 != connect) {
		//mqtt_publish_topic(*client, (*client)->alive, 0, "{\"cycle\":\"death\"}");
		_mqtt_delete_connect(&connect);
	}

	_mqttsub_remove_client(*client, 0);

	if (0 != (*client)->alive) {
		memory_free((*client)->alive);	
	}
	memory_free(*client);
	(*client) = 0;
}
