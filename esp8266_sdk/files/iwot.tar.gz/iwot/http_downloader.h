#ifndef _IWOT_DOWNLOAD_HEADER_
#define _IWOT_DOWNLOAD_HEADER_

#include "iwot_util.h"

#ifdef __cplusplus
extern "C" { 
#endif

//IWOTERRORCODE download_certificate (char *accessKey, char *secretKey, char *host, char **broker, int *port, char **protocol, char **token);
IWOTERRORCODE download_certificate (char *accessKey, char *secretKey, char *host, char **broker, int *port, char **protocol, char **token, char **certificate, char **key);
IWOTERRORCODE download_model (char *accessKey, char *secretKey, char *host, char *id, IWOTMODEL **model);
IWOTERRORCODE download_firmware (char *accessKey, char *secretKey, char *host, char *url, const char *dst);
IWOTERRORCODE download_connect_package(char *accessKey, char *secretKey, char *host, char *id, char **broker, int *port, char **protocol, char **token, char **certificate, char **key, IWOTMODEL **model);

#ifdef __cplusplus
}
#endif

#endif

