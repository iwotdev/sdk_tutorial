#ifndef _IWOT_MQTT_HEADER_
#define _IWOT_MQTT_HEADER_

#ifdef __cplusplus 
extern "C" { 
#endif

#include "iwot_util.h"  

typedef void (*MQTTMSGCALLBACK)(char *topic, char *payload, IWOTVAROBJECT *var, int qos);       

typedef struct _mqttConfig {
    char *cert;
    char *key;
    char *host;    
    int  port;
    char *protocol;
    char *token;
    char *accessKey;
    char *secretKey;
    char *clientID;
    char *id;
    unsigned int keepAlive;
} MQTTCONFIG;

#ifndef __MQTT_CLIENT_C_
typedef struct _mqttConnect MQTTCONNECT;
#endif

typedef struct _mqttClient {
    MQTTCONNECT *connect;
    char *alive;
    char *plkey;
} MQTTCLIENT;

IWOTERRORCODE mqtt_create_client(MQTTCONFIG *config, MQTTCLIENT **result);
IWOTERRORCODE mqtt_subscribe_topic(MQTTCLIENT *client, char *topic, int qos, MQTTMSGCALLBACK callback);
IWOTERRORCODE mqtt_publish_topic(MQTTCLIENT *client, char *topic, int qos, char *payload);
IWOTERRORCODE mqtt_poll_message(MQTTCLIENT *client);

#if IWOT_OPT_ENABLE_MQTT_THREAD
void mqtt_poll_message_thread(MQTTCLIENT *client);
#endif

void mqtt_unsubscribe_topic(MQTTCLIENT *client, char *topic);
void mqtt_delete_client(MQTTCLIENT **result);

#ifdef __cplusplus 
} 
#endif 

#endif