#ifndef _IWOT_UTIL_HEADER_
#define _IWOT_UTIL_HEADER_

#ifdef __cplusplus
extern "C" { 
#endif

#include "iwot_opt.h"    

typedef enum _ecode {
    IWOT_EC_SUCCESS = 0,
    IWOT_EC_INVALID_DATA,    
    IWOT_EC_NULL_DATA,    
    IWOT_EC_INSUFFICIENT_MEMORY,
    IWOT_EC_HTTP_CONNECT_FAILED,
    IWOT_EC_MQTT_CONNECT_FAILED,
    IWOT_EC_MQTT_SUBSCRIBE_FAILED,
    IWOT_EC_MQTT_PUBLISH_FAILED,    
    IWOT_EC_JSON_PARSE_FAILED,
    IWOT_EC_INCONSISTENT_MODEL
} IWOTERRORCODE;    

typedef enum {
    IWOT_INTEGER = 0,
    IWOT_STRING,
    IWOT_BOOLEAN,
    IWOT_FLOAT
} IWOTVARITEMTYPE;    

typedef struct _varItem {
    char* key;
    IWOTVARITEMTYPE type;
    union _varItemValue {
        int integer;
        double floating;
        char *string;
    } value;
} IWOTVARITEM;

typedef struct _varGroup {
    char* identifier;
    int itemCount;
    IWOTVARITEM **items;
    char* timestamp;
    char* status;
    char* id;
} IWOTVARGROUP;

typedef struct _varObject {
    char* identifier;
    int groupCount;
    IWOTVARGROUP **groups;
} IWOTVAROBJECT;

typedef struct _valueDef {
    char *id;
    char *name;
    char *description;
    char *type; /*'integer'|'float'|'boolean'|'string'*/
    char *unit;
    int required; /* 0:false|1:true */
    int minValue;
    int maxValue;
    char **enumerate;    
    int enumerateCount;    
} IWOTVALUEDEF, IWOTVARITEMDEF;

typedef struct _varDef {
    char *id;
    char *name;
    char *description;
    IWOTVALUEDEF **values;
    int valuesCount;
} IWOTVARDEF, IWOTVARGOURPDEF;

typedef struct _model {
    char *id;
    char *classID;
    char *createdAt;
    char *updatedAt;
    char *name;
    char *description;
    char **tags;
    int tagsCount;
    void *customFields;
    void *links;
    IWOTVARDEF **actions;
    int actionsCount;
    IWOTVARDEF **events;
    int eventsCount;
    IWOTVARDEF **properties;
    int propertiesCount;
    void *system;
} IWOTMODEL;

typedef struct _config {
    char *accessKey;
    char *secretKey;
    char *host;
    IWOTVAROBJECT *properties;
    unsigned int keepAlive;
    char *modelJSON;
} IWOTCONFIG;

IWOTERRORCODE iwot_util_create_var_object(const char *identifier, int groupCount, IWOTVAROBJECT **result);
IWOTERRORCODE iwot_util_create_var_group(const char *identifier, int itemCount, const char* timestamp, const char* status, const char* id, IWOTVARGROUP **result);
IWOTERRORCODE iwot_util_create_var_item_string(const char *key, const char *value, IWOTVARITEM **result);
IWOTERRORCODE iwot_util_create_var_item_integer(const char *key, const int value, IWOTVARITEM **result);
#if IWOT_OPT_ENABLE_FPU
IWOTERRORCODE iwot_util_create_var_item_float(const char *key, const double value, IWOTVARITEM **result);
#endif
IWOTERRORCODE iwot_util_create_var_item_boolean(const char *key, const int value, IWOTVARITEM **result);

void iwot_util_free_var_object(IWOTVAROBJECT **object);
void iwot_util_free_var_group(IWOTVARGROUP **group);
void iwot_util_free_var_item(IWOTVARITEM **item);

IWOTERRORCODE iwot_util_create_var_value(const char *id, const char *name, const char *description, const char *type, const char *unit, int required, int minValue, int maxValue, char **enumerate, int enumerateCount, IWOTVALUEDEF **result);
IWOTERRORCODE iwot_util_create_var_def(const char *id, const char *name, const char *description, int valuesCount, IWOTVARDEF **result);
IWOTERRORCODE iwot_util_create_model(const char *id, const char *classID, const char *createdAt, const char *updatedAt, const char *name, const char *description, char **tags, int tagsCount, void *customFields, void *links, int actionsCount, int eventsCount, int propertiesCount, void *system, IWOTMODEL **result);
IWOTERRORCODE iwot_util_create_config(const char *accessKey, const char *secretKey, const char *host, unsigned int keepAlive, const char *modelJSON, IWOTVAROBJECT *properties, IWOTCONFIG **result);

void iwot_util_free_var_value(IWOTVALUEDEF **value);
void iwot_util_free_var_def(IWOTVARDEF **var);
void iwot_util_free_model(IWOTMODEL **model);
void iwot_util_free_config(IWOTCONFIG **config);

IWOTERRORCODE iwot_util_copy_string(const char *src, char **dst);
IWOTERRORCODE iwot_util_copy_string_partial(const char *src, char **dst, int from, int length);
IWOTERRORCODE iwot_util_copy_string_array(char **src, int size, char ***dst);
IWOTERRORCODE iwot_util_create_string_array(int size, char ***dst);

IWOTERRORCODE iwot_util_concat_string(char *src1, size_t len1, char *src2, size_t len2, char **dst);
IWOTERRORCODE iwot_util_concat_memory(char *src1, size_t len1, char *src2, size_t len2, char **dst);

void iwot_util_free_string(char **src);
void iwot_util_free_string_array(char ***src, int size);

#if IWOT_OPT_ENABLE_FPU
IWOTERRORCODE iwot_util_string_to_number(const char *src, int *result_i, double *result_lf);
#endif
IWOTERRORCODE iwot_util_string_to_integer(const char *src, int *result_i);

IWOTERRORCODE iwot_util_verify_object(IWOTMODEL *model, IWOTVAROBJECT *object);
int iwot_util_compare_model(IWOTMODEL *model1, IWOTMODEL *model2);

#ifdef __cplusplus
}
#endif

#endif